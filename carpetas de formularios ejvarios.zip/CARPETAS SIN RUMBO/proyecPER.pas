unit proyecPER;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.Buttons, Vcl.StdCtrls, Vcl.Menus;

type
  TForm1 = class(TForm)
    MainMenu1: TMainMenu;
    Edit1: TEdit;
    Edit2: TEdit;
    entrada: TLabel;
    salida: TLabel;
    Button2: TButton;
    BitBtn1: TBitBtn;
    Button3: TButton;
    Edit3: TEdit;
    Button1: TButton;
    ejercio11: TMenuItem;
    ejercio12: TMenuItem;
    procedure Button3Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure captuarNClick(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure ejercio12Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form1: TForm1;
  n:integer;
   cad:string;
implementation

{$R *.dfm}
 ///funciones
  function seri1(n:integer):real;
   var c, a,b,ex,aum:integer;
       d:byte;
       sumador :real;
  begin
     aum:=3; a:=1; b:=1; ex:=1;sumador:=0;   d:=3;
     while c<=n do
     begin
        if c = 1 then begin
         for  a:= 1 to ex do
           begin

            aum:= a* ex ;

           end;
         b:=b;
        end else begin
            a:=a+2;
             ex:=ex+2;
          for a := 1 to ex  do
           begin
            aum:= a * ex ;
           end;
           b:=b+d;
           d:=+1;

        end;
          sumador:= sumador +( aum/b);
          inc(c);
     end;
        result:= sumador;
  end;


 /// finfunciones


 ///capprutra N
procedure TForm1.captuarNClick(Sender: TObject);
begin
 n:= StrToInt(edit1.text);
end;

procedure TForm1.ejercio12Click(Sender: TObject);
begin
edit3.Text:= FloatToStr(seri1(n));
end;

procedure TForm1.Button1Click(Sender: TObject);
begin
n:= StrToInt(edit1.text);
showmessage('numero registrado'+ IntToStr(n));
end;

procedure TForm1.Button2Click(Sender: TObject);
begin
cad:= edit1.Text;
 showmessage('cadena registrada : '+ cad);
end;

procedure TForm1.Button3Click(Sender: TObject);
begin
    edit1.Clear;
   edit2.Clear;
end;

end.
