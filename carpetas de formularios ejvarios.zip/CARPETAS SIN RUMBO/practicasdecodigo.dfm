object Form1: TForm1
  Left = 0
  Top = 0
  Caption = 'Form1'
  ClientHeight = 543
  ClientWidth = 807
  Color = clActiveCaption
  Font.Charset = ANSI_CHARSET
  Font.Color = clWindowText
  Font.Height = -16
  Font.Name = 'Courier New'
  Font.Style = [fsBold]
  Menu = MainMenu1
  PixelsPerInch = 96
  TextHeight = 18
  object ENTRADA: TLabel
    Left = 20
    Top = 73
    Width = 80
    Height = 20
    Caption = 'ENTRADA'
    Color = clNavy
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Showcard Gothic'
    Font.Style = [fsBold]
    ParentColor = False
    ParentFont = False
  end
  object SALIDA: TLabel
    Left = 28
    Top = 118
    Width = 55
    Height = 20
    Caption = 'SALIDA'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Showcard Gothic'
    Font.Style = []
    ParentFont = False
  end
  object LONGUITUD: TLabel
    Left = 8
    Top = 166
    Width = 92
    Height = 20
    Caption = 'LONGUITUD'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Showcard Gothic'
    Font.Style = []
    ParentFont = False
  end
  object Edit1: TEdit
    Left = 121
    Top = 75
    Width = 346
    Height = 22
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'Courier New'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 0
    Text = 'Edit1'
  end
  object Edit2: TEdit
    Left = 121
    Top = 120
    Width = 353
    Height = 24
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Courier New'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 1
    Text = 'Edit2'
  end
  object Edit3: TEdit
    Left = 121
    Top = 167
    Width = 353
    Height = 26
    TabOrder = 2
    Text = 'Edit3'
  end
  object capturaN: TButton
    Left = 20
    Top = 273
    Width = 109
    Height = 88
    Caption = 'ENTRADAdeN'
    TabOrder = 3
    OnClick = Button1Click
  end
  object Button2: TButton
    Left = 135
    Top = 275
    Width = 162
    Height = 84
    Caption = 'REGISTRO_CADENA'
    TabOrder = 4
    OnClick = Button2Click
  end
  object Button3: TButton
    Left = 28
    Top = 389
    Width = 213
    Height = 34
    Caption = 'longuitud cadena'
    TabOrder = 5
    OnClick = Button3Click
  end
  object limpieza: TButton
    Left = 321
    Top = 229
    Width = 153
    Height = 34
    Caption = 'limpieza'
    TabOrder = 6
    OnClick = limpiezaClick
  end
  object BitBtn1: TBitBtn
    Left = 392
    Top = 318
    Width = 75
    Height = 41
    Kind = bkClose
    NumGlyphs = 2
    TabOrder = 7
  end
  object ListBox1: TListBox
    Left = 504
    Top = 94
    Width = 257
    Height = 363
    Color = clMenuBar
    ItemHeight = 18
    TabOrder = 8
  end
  object MainMenu1: TMainMenu
    Left = 728
    Top = 16
    object chat1: TMenuItem
      Caption = 'chat'
      OnClick = chat1Click
      object chat2: TMenuItem
        Caption = 'chat1'
        OnClick = chat2Click
      end
      object chat21: TMenuItem
        Caption = 'chat2'
        OnClick = chat21Click
      end
      object chat31: TMenuItem
        Caption = 'chat3'
        OnClick = chat31Click
      end
      object chat41: TMenuItem
        Caption = 'chat4'
        OnClick = chat41Click
      end
      object chat51: TMenuItem
        Caption = 'chat5'
        OnClick = chat51Click
      end
      object chat61: TMenuItem
        Caption = 'chat6'
        OnClick = chat61Click
      end
      object chat62: TMenuItem
        Caption = 'chat7'
        OnClick = chat62Click
      end
      object chat81: TMenuItem
        Caption = 'chat8'
      end
      object chat82: TMenuItem
        Caption = 'chat9'
      end
      object chat101: TMenuItem
        Caption = 'chat10'
      end
      object chat102: TMenuItem
        Caption = 'chat11'
        OnClick = chat102Click
      end
    end
    object tarea1: TMenuItem
      Caption = 'tarea'
      OnClick = tarea1Click
      object tarea11: TMenuItem
        Caption = 'tarea1'
        OnClick = tarea11Click
      end
      object tarea12: TMenuItem
        Caption = 'tarea2'
        OnClick = tarea12Click
      end
      object tarea31: TMenuItem
        Caption = 'tarea3'
        OnClick = tarea31Click
      end
      object tareafinal11: TMenuItem
        Caption = 'tareafinal1'
        OnClick = tareafinal11Click
      end
      object tareafinal21: TMenuItem
        Caption = 'tareafinal2'
        OnClick = tareafinal21Click
      end
      object tareafinal31: TMenuItem
        Caption = 'tareafinal3'
        OnClick = tareafinal31Click
      end
    end
    object autodidacta1: TMenuItem
      Caption = 'autodidacta'
      object autodidacta2: TMenuItem
        Caption = 'au1'
        OnClick = autodidacta2Click
      end
      object au21: TMenuItem
        Caption = 'au2'
        OnClick = au21Click
      end
      object au31: TMenuItem
        Caption = 'au3'
        OnClick = au31Click
      end
      object au41: TMenuItem
        Caption = 'au4'
        OnClick = au41Click
      end
      object au51: TMenuItem
        Caption = 'au5'
        OnClick = au51Click
      end
      object au61: TMenuItem
        Caption = 'au6'
        OnClick = au61Click
      end
      object au71: TMenuItem
        Caption = 'au7'
        OnClick = au71Click
      end
      object au81: TMenuItem
        Caption = 'au8'
        OnClick = au81Click
      end
    end
    object examen1: TMenuItem
      Caption = 'practico'
      object examen2: TMenuItem
        Caption = 'ejercicio1'
        OnClick = examen2Click
      end
      object ejercicio21: TMenuItem
        Caption = 'ejercicio2'
        OnClick = ejercicio21Click
      end
      object ejercicio22: TMenuItem
        Caption = 'ejercicio3'
      end
      object mostardigitosordenados1: TMenuItem
        Caption = 'mostardigitosordenados'
        OnClick = mostardigitosordenados1Click
      end
      object buscarCHARintroducidoYMOTRARcuantasVserepite1: TMenuItem
        Caption = 'buscarCHARintroducidoYMOTRARcuantas Vserepite'
        OnClick = buscarCHARintroducidoYMOTRARcuantasVserepite1Click
      end
      object mostrarCARenidnePAR1: TMenuItem
        Caption = 'mostrarCARenindicePAR'
        OnClick = mostrarCARenidnePAR1Click
      end
      object insertarSUBcadapartirDElaSEGpal1: TMenuItem
        Caption = 'insertarSUBcadapartirDElaSEGpal'
        OnClick = insertarSUBcadapartirDElaSEGpal1Click
      end
      object ELIMconsoULTpal1: TMenuItem
        Caption = 'ELIMconsoULTpal'
        OnClick = ELIMconsoULTpal1Click
      end
      object elimPAlqueCOMenC1: TMenuItem
        Caption = 'elimPAlqueCOMenC'
        OnClick = elimPAlqueCOMenC1Click
      end
      object CONaMAYUSlosPRIcharDEcadaPAl1: TMenuItem
        Caption = 'CONaMAYUSlosPRIcharDEcadaPAl'
        OnClick = CONaMAYUSlosPRIcharDEcadaPAl1Click
      end
    end
    object modelodeexamen1: TMenuItem
      Caption = 'varios'
      object modelodeexamen2: TMenuItem
        Caption = 'sumatoriadefibonacifactorial'
        OnClick = modelodeexamen2Click
      end
      object mod21: TMenuItem
        Caption = 'sumadeimpares'
        OnClick = mod21Click
      end
      object mod31: TMenuItem
        Caption = 'menora6'
        OnClick = mod31Click
      end
      object mod41: TMenuItem
        Caption = 'timased'
        OnClick = mod41Click
      end
      object mod42: TMenuItem
        Caption = 'invertirpala'
        OnClick = mod42Click
      end
      object mod61: TMenuItem
        Caption = 'sumaS<=Nimparespares'
        OnClick = mod61Click
      end
      object mod71: TMenuItem
        Caption = 'sumadelosNDGymostrarlaSmayor'
        OnClick = mod71Click
      end
      object mod81: TMenuItem
        Caption = 'mod8'
        OnClick = mod81Click
      end
      object mod91: TMenuItem
        Caption = 'mayusculasiterminaenA'
        OnClick = mod91Click
      end
      object mod101: TMenuItem
        Caption = 'serie := 3 + 18 + 53'
        OnClick = mod101Click
      end
      object mod111: TMenuItem
        Caption = 'eliminarnumerorepetitivo'
        OnClick = mod111Click
      end
      object serie202112331: TMenuItem
        Caption = 'serie= 2/0!+2^1/1!+2^3/3!'
        OnClick = serie202112331Click
      end
      object ordenarMODburbuja1: TMenuItem
        Caption = 'ordenarMODburbuja'
        OnClick = ordenarMODburbuja1Click
      end
      object ordDEASC2pal1: TMenuItem
        Caption = 'ordDEASC2pal'
        OnClick = ordDEASC2pal1Click
      end
      object capicuaIZQUI1: TMenuItem
        Caption = 'capicuaIZQUI'
        OnClick = capicuaIZQUI1Click
      end
      object serie1112221: TMenuItem
        Caption = 'serie: 1!*1^1+2!*2^2...'
        OnClick = serie1112221Click
      end
      object sumarDGprimosSELOSN1: TMenuItem
        Caption = 'sumarDGprimosSELOSN'
        OnClick = sumarDGprimosSELOSN1Click
      end
      object ANAestudiaCONada1: TMenuItem
        Caption = 'ANAestudiaCONada'
        OnClick = ANAestudiaCONada1Click
      end
      object ana1: TMenuItem
        Caption = 'ana'
        OnClick = ana1Click
      end
      object potencia1: TMenuItem
        Caption = 'potencia'
        OnClick = potencia1Click
      end
    end
    object miercoles1: TMenuItem
      Caption = 'miercoles'
      object miercoles2: TMenuItem
        Caption = 'numeromenor'
        OnClick = miercoles2Click
      end
      object ej11: TMenuItem
        Caption = 'promedioprimeroyultimo'
        OnClick = ej11Click
      end
      object ej31: TMenuItem
        Caption = 'numeroprimoconindicepar'
        OnClick = ej31Click
      end
      object sumaDGcentro1: TMenuItem
        Caption = 'sumaDGcentro'
        OnClick = sumaDGcentro1Click
      end
      object sumaDGcentro2: TMenuItem
        Caption = 'ordenarnumero'
        OnClick = sumaDGcentro2Click
      end
      object espalabra1: TMenuItem
        Caption = 'espalabra'
      end
      object espalabra2: TMenuItem
        Caption = 'esespacio'
        OnClick = espalabra2Click
      end
    end
    object eaxemenz21: TMenuItem
      Caption = 'rep'
      object ej12: TMenuItem
        Caption = 'factorial 1!+3!+5!.sumar terminos impares'
        OnClick = ej12Click
      end
      object ej13: TMenuItem
        Caption = 'contarPALcomienzeENVOCytengavocalseguida'
        OnClick = ej13Click
      end
      object N1j31: TMenuItem
        Caption = '1j3'
        OnClick = N1j31Click
      end
    end
    object e1: TMenuItem
      Caption = 'Examen_Final'
      object ejerciofinal11: TMenuItem
        Caption = 'ejerciofinal1'
        OnClick = ejerciofinal11Click
      end
      object ejerciofinal12: TMenuItem
        Caption = 'ejerciciofinal2'
        OnClick = ejerciofinal12Click
      end
      object ejerciciofinal31: TMenuItem
        Caption = 'ejerciciofinal3'
        OnClick = ejerciciofinal31Click
      end
      object ejerciciofinal32: TMenuItem
        Caption = ' ultimo'
        OnClick = ejerciciofinal32Click
      end
    end
  end
end
