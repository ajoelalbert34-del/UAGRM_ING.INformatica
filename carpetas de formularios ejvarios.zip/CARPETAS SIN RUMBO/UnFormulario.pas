unit UnFormulario;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs,UCnaturales, Vcl.StdCtrls, Vcl.Buttons,
  Vcl.Menus;

type
  TForm1 = class(TForm)
    Edit1: TEdit;
    Edit2: TEdit;
    crear: TLabel;
    CambiarValordeN: TLabel;
    Button1: TButton;
    BitBtn1: TBitBtn;
    MainMenu1: TMainMenu;
    mostrarPOO1: TMenuItem;
    contarDg1: TMenuItem;
    ccmabiarvalorDG1: TMenuItem;
    obtener1: TMenuItem;
    Button2: TButton;
    clasePOO1: TMenuItem;
    promeN1: TMenuItem;
    dgPRIMO1: TMenuItem;
    binario1: TMenuItem;
    binario2: TMenuItem;
    modeloexamen1: TMenuItem;
    modeloexamen2: TMenuItem;
    mod21: TMenuItem;
    mod31: TMenuItem;
    tareaPOO1: TMenuItem;
    tareaPOO2: TMenuItem;
    tarea21: TMenuItem;
    tarea31: TMenuItem;
    tarea41: TMenuItem;
    ordenarnumero1: TMenuItem;
    promedioprimeryultimodigito1: TMenuItem;
    numeromenor1: TMenuItem;
    digitoprimoconindicepar1: TMenuItem;
    sumadelosdigitosdelcentro1: TMenuItem;
    ordenar1: TMenuItem;
    ordenar2: TMenuItem;
    promPRiultMED1: TMenuItem;
    ExamenFInal1: TMenuItem;
    ejercicioFianl11: TMenuItem;
    ejercicioFianl12: TMenuItem;
    ejerciciofinal31: TMenuItem;
    ejerciciofinal32: TMenuItem;
    procedure CambiarValordeNClick(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure crearClick(Sender: TObject);
    procedure contarDg1Click(Sender: TObject);
    procedure ccmabiarvalorDG1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure promeN1Click(Sender: TObject);
    procedure clasePOO1Click(Sender: TObject);
    procedure dgPRIMO1Click(Sender: TObject);
    procedure binario1Click(Sender: TObject);
    procedure binario2Click(Sender: TObject);
    procedure modeloexamen2Click(Sender: TObject);
    procedure mod31Click(Sender: TObject);
    procedure tareaPOO2Click(Sender: TObject);
    procedure tarea21Click(Sender: TObject);
    procedure tarea31Click(Sender: TObject);
    procedure tarea41Click(Sender: TObject);
    procedure ordenarnumero1Click(Sender: TObject);
    procedure promedioprimeryultimodigito1Click(Sender: TObject);
    procedure numeromenor1Click(Sender: TObject);
    procedure digitoprimoconindicepar1Click(Sender: TObject);
    procedure sumadelosdigitosdelcentro1Click(Sender: TObject);
    procedure ordenar2Click(Sender: TObject);
    procedure promPRiultMED1Click(Sender: TObject);
    procedure Label1Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form1: TForm1;
  NUMERO:NumeroNatural;
  cad:string;
  n,i:byte;
implementation

{$R *.dfm}

procedure TForm1.promedioprimeryultimodigito1Click(Sender: TObject);
begin
  edit2.Text:= FloatToStr(Numero.promedioDG)+ ' : el promedio del primer y el ultimo digito es ';
end;

procedure TForm1.promeN1Click(Sender: TObject);
begin
edit2.Text:= FloatToStr(Numero.promN);
end;

procedure TForm1.promPRiultMED1Click(Sender: TObject);

begin
edit2.Text:= FloatToStr(Numero.prompriultmed)+ ' : es el promedio del primer ,ultimo y termino medio';
end;

procedure TForm1.sumadelosdigitosdelcentro1Click(Sender: TObject);
begin
 edit2.Text:=IntToStr(Numero.sumaDGcentro)+ ' : la suma de los digitos del centro son';
end;

procedure TForm1.tarea21Click(Sender: TObject);
begin
 edit2.Text:=IntToStr(Numero.primeryultimo)+ ' : es el resultado sin el primer y ultimo digito';
end;

procedure TForm1.tarea31Click(Sender: TObject);
begin
 edit2.Text:=(Numero.pares) + ' : son los pares';
end;

procedure TForm1.tarea41Click(Sender: TObject);
begin
 edit2.Text:=IntToStr(Numero.imparindice)+ ' son los numeros con indices impares';
end;

procedure TForm1.tareaPOO2Click(Sender: TObject);
begin
edit2.Text:=(Numero.octal) + ': es su equivalente en octal';
end;

///mostrar
procedure TForm1.binario1Click(Sender: TObject);
begin
   edit2.Text:= (Numero.DGbin);
end;

procedure TForm1.binario2Click(Sender: TObject);
begin
edit2.Text:= IntToStr(Numero.DGmayor);
end;

procedure TForm1.Button1Click(Sender: TObject);
begin
 edit2.Text:=IntToStr(Numero.ObtenerValor);
end;


procedure TForm1.Button2Click(Sender: TObject);
begin
 edit1.clear;
 edit2.clear;
end;

//crear
procedure TForm1.crearClick(Sender: TObject);
begin
 Numero:=NumeroNatural.create;
 showmessage('Numero creado');
end;

procedure TForm1.dgPRIMO1Click(Sender: TObject);
begin
edit2.Text:= IntToStr(Numero.DGprimo);
end;

procedure TForm1.digitoprimoconindicepar1Click(Sender: TObject);
begin
 edit2.Text:= IntToStr(Numero.digitoprimoconindicepar)+' : el digito primo con idice par ';
end;

procedure TForm1.Label1Click(Sender: TObject);
begin

end;

///prueba
procedure TForm1.mod31Click(Sender: TObject);
 var c,i:integer;
     acu,fac,n:word;
begin
     while c<=n do
     begin
       for i :=1 to fac do
        begin
         acu:= fac * i;
        end;
        fac:=fac+2;
       c:=c+1;
     end;
     edit2.Text:= IntToStr(acu);
end;

procedure TForm1.modeloexamen2Click(Sender: TObject);
begin
edit2.Text:= FloatToStr(Numero.sumafac) ;
end;

procedure TForm1.numeromenor1Click(Sender: TObject);
begin
edit2.Text:= IntToStr(Numero.digitomenor)+ ' el digito menor es ' ;
end;

////ordenar numero
procedure TForm1.ordenar2Click(Sender: TObject);
var auxi:char; // string
   j:byte;
  i: Integer;
begin
    for i := 1 to n-1 do
     for j := i+1 to n do
      begin
         if cad[i]> cad[j] then
         begin
           auxi:=cad[i];
           cad[i]:= cad[j];
           cad[j]:= auxi;
         end;
      end;
     edit2.text:= cad;
end;

procedure TForm1.ordenarnumero1Click(Sender: TObject);
begin
   edit2.Text:= (Numero.ordenarnumero)+ ' : el numero ordenado es';
end;

////cambiar valor
procedure TForm1.CambiarValordeNClick(Sender: TObject);
begin
  Numero.CambiarValor(StrToInt(edit1.Text));
 showmessage('Valor asignado');

end;

//obtenervalor
procedure TForm1.ccmabiarvalorDG1Click(Sender: TObject);
begin
edit2.text:=IntToStr(Numero.ObtenerValor);
end;
procedure TForm1.clasePOO1Click(Sender: TObject);
begin

end;

//contar digito
procedure TForm1.contarDg1Click(Sender: TObject);
begin
  edit2.Text:= IntToStr(Numero.ContarDigito) + 'digitos';
end;



end.
