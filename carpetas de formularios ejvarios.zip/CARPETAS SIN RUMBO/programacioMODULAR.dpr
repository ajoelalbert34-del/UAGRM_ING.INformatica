program programacioMODULAR;
uses
  System.SysUtils;

begin
  writeln('fernanda dame un beso');
end.
