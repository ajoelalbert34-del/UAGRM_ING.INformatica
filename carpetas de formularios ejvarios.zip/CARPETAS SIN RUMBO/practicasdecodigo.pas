unit practicasdecodigo;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.StrUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, Vcl.Menus, Vcl.Buttons,math;

type
  TForm1 = class(TForm)
    MainMenu1: TMainMenu;
    ENTRADA: TLabel;
    SALIDA: TLabel;
    LONGUITUD: TLabel;
    Edit1: TEdit;
    Edit2: TEdit;
    Edit3: TEdit;
    Button2: TButton;
    Button3: TButton;
    limpieza: TButton;
    BitBtn1: TBitBtn;
    ListBox1: TListBox;
    capturaN: TButton;
    chat1: TMenuItem;
    chat2: TMenuItem;
    chat21: TMenuItem;
    chat31: TMenuItem;
    chat41: TMenuItem;
    chat51: TMenuItem;
    chat61: TMenuItem;
    chat62: TMenuItem;
    chat81: TMenuItem;
    chat82: TMenuItem;
    chat101: TMenuItem;
    chat102: TMenuItem;
    tarea1: TMenuItem;
    tarea11: TMenuItem;
    tarea12: TMenuItem;
    tarea31: TMenuItem;
    autodidacta1: TMenuItem;
    autodidacta2: TMenuItem;
    au21: TMenuItem;
    au31: TMenuItem;
    au41: TMenuItem;
    examen1: TMenuItem;
    examen2: TMenuItem;
    ejercicio21: TMenuItem;
    ejercicio22: TMenuItem;
    modelodeexamen1: TMenuItem;
    modelodeexamen2: TMenuItem;
    mod21: TMenuItem;
    mod31: TMenuItem;
    mod41: TMenuItem;
    mod42: TMenuItem;
    mod61: TMenuItem;
    mod71: TMenuItem;
    mod81: TMenuItem;
    mod91: TMenuItem;
    mod101: TMenuItem;
    mod111: TMenuItem;
    au51: TMenuItem;
    au61: TMenuItem;
    au71: TMenuItem;
    au81: TMenuItem;
    miercoles1: TMenuItem;
    miercoles2: TMenuItem;
    ej11: TMenuItem;
    ej31: TMenuItem;
    sumaDGcentro1: TMenuItem;
    sumaDGcentro2: TMenuItem;
    eaxemenz21: TMenuItem;
    ej12: TMenuItem;
    ej13: TMenuItem;
    N1j31: TMenuItem;
    serie202112331: TMenuItem;
    ordenarMODburbuja1: TMenuItem;
    ordDEASC2pal1: TMenuItem;
    capicuaIZQUI1: TMenuItem;
    serie1112221: TMenuItem;
    sumarDGprimosSELOSN1: TMenuItem;
    espalabra1: TMenuItem;
    espalabra2: TMenuItem;
    ANAestudiaCONada1: TMenuItem;
    mostardigitosordenados1: TMenuItem;
    buscarCHARintroducidoYMOTRARcuantasVserepite1: TMenuItem;
    mostrarCARenidnePAR1: TMenuItem;
    insertarSUBcadapartirDElaSEGpal1: TMenuItem;
    tareafinal11: TMenuItem;
    tareafinal21: TMenuItem;
    tareafinal31: TMenuItem;
    ana1: TMenuItem;
    ELIMconsoULTpal1: TMenuItem;
    elimPAlqueCOMenC1: TMenuItem;
    CONaMAYUSlosPRIcharDEcadaPAl1: TMenuItem;
    e1: TMenuItem;
    ejerciofinal11: TMenuItem;
    ejerciofinal12: TMenuItem;
    ejerciciofinal31: TMenuItem;
    ejerciciofinal32: TMenuItem;
    potencia1: TMenuItem;
    procedure Button1Click(Sender: TObject);
    procedure limpiezaClick(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure chat2Click(Sender: TObject);
    procedure chat21Click(Sender: TObject);
    procedure chat31Click(Sender: TObject);
    procedure chat41Click(Sender: TObject);
    procedure chat51Click(Sender: TObject);
    procedure chat61Click(Sender: TObject);
    procedure chat62Click(Sender: TObject);
    procedure tarea11Click(Sender: TObject);
    procedure tarea12Click(Sender: TObject);
    procedure tarea31Click(Sender: TObject);
    procedure autodidacta2Click(Sender: TObject);
    procedure au21Click(Sender: TObject);
    procedure au31Click(Sender: TObject);
    procedure au41Click(Sender: TObject);
    procedure examen2Click(Sender: TObject);
    procedure ejercicio21Click(Sender: TObject);
    procedure chat1Click(Sender: TObject);
    procedure chat102Click(Sender: TObject);
    procedure modelodeexamen2Click(Sender: TObject);
    procedure mod21Click(Sender: TObject);
    procedure mod31Click(Sender: TObject);
    procedure mod42Click(Sender: TObject);
    procedure mod41Click(Sender: TObject);
    procedure mod62Click(Sender: TObject);
    procedure mod61Click(Sender: TObject);
    procedure mod71Click(Sender: TObject);
    procedure mod81Click(Sender: TObject);
    procedure mod91Click(Sender: TObject);
    procedure mod101Click(Sender: TObject);
    procedure mod111Click(Sender: TObject);
    procedure au51Click(Sender: TObject);
    procedure au61Click(Sender: TObject);
    procedure au71Click(Sender: TObject);
    procedure au81Click(Sender: TObject);
    procedure miercoles2Click(Sender: TObject);
    procedure ej11Click(Sender: TObject);
    procedure ej31Click(Sender: TObject);
    procedure sumaDGcentro1Click(Sender: TObject);
    procedure sumaDGcentro2Click(Sender: TObject);
    procedure serie202112331Click(Sender: TObject);
    procedure ordenarMODburbuja1Click(Sender: TObject);
    procedure ordDEASC2pal1Click(Sender: TObject);
    procedure capicuaIZQUI1Click(Sender: TObject);
    procedure serie1112221Click(Sender: TObject);
    procedure sumarDGprimosSELOSN1Click(Sender: TObject);
    procedure espalabra2Click(Sender: TObject);
    procedure ANAestudiaCONada1Click(Sender: TObject);
    procedure ej12Click(Sender: TObject);
    procedure ej13Click(Sender: TObject);
    procedure mostardigitosordenados1Click(Sender: TObject);
    procedure buscarCHARintroducidoYMOTRARcuantasVserepite1Click(
      Sender: TObject);
    procedure mostrarCARenidnePAR1Click(Sender: TObject);
    procedure insertarSUBcadapartirDElaSEGpal1Click(Sender: TObject);
    procedure tareafinal11Click(Sender: TObject);
    procedure tareafinal21Click(Sender: TObject);
    procedure tareafinal31Click(Sender: TObject);
    procedure tarea1Click(Sender: TObject);
    procedure ana1Click(Sender: TObject);
    procedure ELIMconsoULTpal1Click(Sender: TObject);
    procedure elimPAlqueCOMenC1Click(Sender: TObject);
    procedure CONaMAYUSlosPRIcharDEcadaPAl1Click(Sender: TObject);
    procedure N1j31Click(Sender: TObject);
    procedure potencia1Click(Sender: TObject);
    procedure ejerciofinal11Click(Sender: TObject);
    procedure ejerciofinal12Click(Sender: TObject);
    procedure ejerciciofinal31Click(Sender: TObject);
    procedure ejerciciofinal32Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form1: TForm1;
 n,i:integer;
  cad,cad2:string;
  car,caracter:char;
  lon:integer;

implementation

{$R *.dfm}
    /////implementacion de funciones
    //2)funcion para verificar si  un caracter es vocal
function esvocal(cad: string ; car:char):boolean;
 begin
    // result:= car in ['a', 'e','i','o','u','A','E','I','O','U'] ;
     result:= cad[i] in ['a', 'e','i','o','u','A','E','I','O','U'] ;

 end;
    //2)funcion para invertir una cadena
function invercad(cad:string):String;
begin
  result:=System.StrUtils.ReverseString(cad);
end;
    ///version formal
  function invertircadena(cad:string): string;
  var i:byte;
     modi:string;
  begin
    i:=1;  modi:='';
    for i := length(cad) downto 1 do
     begin
       modi:= modi + cad[i];
     end;
     result:= modi;
  end;
  //3)funcion para verificar si es espacio
   function espacioblanco(cad:string ; car:char):boolean;
   begin
    // result:= car = '' ;
     result:= cad[i] = '' ;
   end;

  //4)funcion para saber si es numero
     function esnumero(cad:string; car:char):boolean;

     begin
      // result:= car in ['0'..'9'];
       result:= cad[i] in ['0'..'9' ];
     end;
    //5)funcion parasaber si es palindromo
    function espalindromo(cad:string):boolean;
     var original ,invertida:string;
    begin
        original:=cad;
        invertida:= System.StrUtils.ReverseString(cad);
        result:= original = invertida;
    end;
    //6)funcion para contar vocales
     function numvoc(cad:string):integer;
     var c:integer;
          i:byte;
     begin
     i:=1;   c:=0;
          for i := 1 to length(cad) do
            begin

               if  cad[i] in ['a', 'e','i','o','u','A','E','I','O','U'] then begin
                 c:=c+1;
               end;

            end;
            result:=c;
     end;
     ///7) eliminar las vocales de una cadena
     function elimvoc(cad:string):string;
     var modificada:string;
     begin
           for i := 1 to length(cad) do
             begin
               if  not(cad[i]  in ['a', 'e','i','o','u','A','E','I','O','U']) then
               modificada:= modificada + cad[i];
             end;
             result:= modificada;
     end;
     //8) cambiar vocales
     function cambvoc(cad:string):string;
     var modificada:string;
         caracter : char;
         i:integer;
     begin
         modificada:='';
          for i := 1 to length(cad) do
             begin
               if  cad[i]  in ['a', 'e','i','o','u','A','E','I','O','U'] then begin
                modificada:= modificada + caracter ;

               end else begin
                  modificada:= modificada + cad[i];
               end;

             end ;
             result:= modificada;
     end;

     /// funcion para verificar si comienza en un X caracter
      function caracterempieza(cad:string): boolean;
       var sw:boolean;
            cade:string;
            i:byte;
       begin
       i:=1; sw:=false;
         cade:= inputbox('ingrese un caracter','solo un','');

         if ((cad[i] = cade) and (i=1)) or ((cade[i]=' ')and (cade[i+1]=car))  then
         begin
           sw:=true;
         end;
         result:= (sw) ;
       end;
function invertir(cad: string):string;
var
i:byte;
c:string;
begin
   i:=length(cad);
   c:='';
   while i>0 do begin
      c:=c+cad[i];
      i:=i-1;
   end;
   result:=c;
end;

function nose(cad: string): string;
var
i,s:byte;
c,r,t:string;
begin
   i:=1;
   s:=0;
   c:='';
   r:='';
   while i<=length(cad) do begin
      while (i<=length(cad)) and (cad[i] <> ' ') do begin
      c:=c+cad[i];
      i:=i+1;
      end;
      if (c = invertir(c)) and (length(c) > 1) then begin
        s:=s+1;
        r:=r+c+',';
      end;
      c:='';
      i:=i+1;
   end;
   r[length(r)]:=' ';
   t:='son '+ (inttostr(s)) + ', y son: '+ r;
   result:= t;
end;
    ////fin de implementacion de funciones



//proceso capturar n
procedure TForm1.ana1Click(Sender: TObject);
var
  i, k: Integer;
  modi, cade: string;
begin
  i := 1;
  k := 1;
  modi := '';
  cade := '';

  while i <= Length(cad) do
  begin
    if (cad[i] = ' ') or (i = Length(cad)) then
    begin

      if cad[i] = ' ' then
      begin
        cade := Copy(cad, k, i - k);
      end
      else
      begin
        cade := Copy(cad, k, i - k + 1);
      end;

      modi := modi + InvertirCadena(cade);
      if i < Length(cad) then
      begin
        modi := modi + ' ';
      end;
      k := i + 1;
    end;
    i:=i+1;;
  end;

end;

procedure TForm1.ANAestudiaCONada1Click(Sender: TObject);
var
  cad, palabra, palabraInvertida: string;
  i, n, palindromos: Integer;
  esPalindromo: Boolean;
begin
  cad := 'ada estudia con ana';
  n := Length(cad);
  palabra := '';
  palabraInvertida := '';
  palindromos := 0;
  i := 1;

  while i <= n do
  begin
    if cad[i] <> ' ' then
    begin

      palabra := palabra + cad[i];
      palabraInvertida := cad[i] + palabraInvertida;
    end
    else
    begin
      if palabra <> '' then
      begin
        esPalindromo := True;
        for var j := 1 to Length(palabra) do
        begin
          if palabra[j] <> palabra[Length(palabra) - j + 1] then
          begin
            esPalindromo := False;
          end;
        end;

        if esPalindromo then
          Inc(palindromos);

        Edit1.Text := Edit1.Text + palabraInvertida + ' ';
      end;

      palabra := '';
      palabraInvertida := '';
    end;

    Inc(i);
  end;

  if palabra <> '' then
  begin
    esPalindromo := True;
    for var j := 1 to Length(palabra) do
    begin
      if palabra[j] <> palabra[Length(palabra) - j + 1] then
      begin
        esPalindromo := False;
      end;
    end;
    if esPalindromo then
      Inc(palindromos);
    Edit1.Text := Edit1.Text + palabraInvertida + ' ';
  end;

  Edit2.Text := IntToStr(palindromos) + ' pal�ndromos encontrados';
end;

procedure TForm1.au21Click(Sender: TObject);
 var modificado,k,num,invertido:integer;
     i,c:byte;
begin
     n:=StrToInt(edit1.text);
     k := StrToInt(edit2.text);
     showmessage( IntToStr(k));
    invertido:=0;  num:=0;  c:=0; i:=1;  modificado:=0;
      while n>0 do
       begin
        num:= n mod 10 ;
        invertido :=invertido * 10 + num;
        n:= n div 10;

       end;

        showmessage(IntToStr(invertido));


      while invertido>0 do
      begin
         num:= invertido mod 10;

        if c = k then
         begin
          modificado:=modificado *10 + num;
          showmessage(IntToStr(modificado));
          c:=c-1;
         end;
         invertido:=invertido div 10 ;
         c:=c+1;
      end;
       edit2.Text:= IntToStr(modificado);
end;

procedure TForm1.au31Click(Sender: TObject);
var
  modificada: string;
  i: Integer;
  es: Boolean;
begin
  modificada := '';
  es := True;
  for i := 1 to Length(cad) do
  begin
    if es then
    begin
      modificada := modificada + UpCase(cad[i]);
      es := False; // Cambiamos el estado para indicar que ya no estamos al inicio de una palabra
    end
    else
    begin
      // Si encontramos un espacio, lo agregamos tal cual y marcamos el inicio de una nueva palabra
      if cad[i] = ' ' then
      begin
        modificada := modificada + cad[i];
        es := True; // El pr�ximo car�cter ser� el inicio de una palabra
      end
      else
      begin
        // Agregar los caracteres normales tal cual
        modificada := modificada + cad[i];
      end;
    end;
  end;
  // Mostrar el resultado en el componente Edit2
  Edit2.Text := modificada;

{var modificada:string;
es:integer;
begin
es:=0; i:=1; modificada:='';
      lon:=length(cad);
  while i<= lon do
   begin
      if es = 0 then
       begin
           modificada :=modificada + upcase(cad[i]);
            showmessage(modificada);
                es:=es +1;
               i:=i+1;
       end;
          if  es >= 2 then
        begin

              if cad[i] = ' ' then begin
              modificada:=modificada + upcase( cad[i +1]);
               showmessage(modificada);
        end else begin
                  modificada:=modificada + cad [i];

        end;


       i:=i+1

    end;

    edit2.Text:= modificada; }


 end;

   function conver(cad:string):string;
   var i:byte;
       modi:string;
   begin
        i:=1; modi:='';
        while i<= length(cad) do
         begin
           if (cad[i] <> ' ') and ((i = 1) or (cad[i - 1] = ' '))  then
         begin
          modi:= modi+ upcase(cad[i]);
         end else begin
          modi:= modi + cad[i];
         end;
         i:=i+1;
         end;
      result:= modi;
   end;
procedure TForm1.au41Click(Sender: TObject);
 var i:integer;
     modi:string;
begin
     modi:='';   i:=1;
     while i <= length(cad) do
       begin
         if (cad[i] <> ' ') and ((i = 1) or (cad[i - 1] = ' ')) then

         begin
          modi:= modi+ upcase(cad[i]);
         end else begin
          modi:= modi + cad[i];
         end;

         i:=i+1;
       end;
       edit2.Text:= modi;


end;

////octal
  procedure TForm1.au51Click(Sender: TObject);
  var octal,num,inver:integer;
begin
   octal:=0; inver:=0;
    while n>0 do
   begin
   showmessage(IntToStr(n)+' : el numero es');
   num:= n mod 8;
   n:= n div 8 ;
    if num in [0..7]then
    begin
     octal:=(octal*10)+ num;

    end;
     showmessage(IntToStr(octal)+ ' : el octal invertido es  ');
   end;
     while octal>0 do
     begin
       num:= octal mod 10;
       inver:= inver * 10 + num;
       octal:= octal div 10;
        showmessage(IntToStr(inver)+ ' : el octal es  ');
     end;

   edit2.Text:= IntToStr(inver);

end;

///primero y ultimo
procedure TForm1.au61Click(Sender: TObject);
var acu,num,final,l:integer;
begin
 acu:=0; final:=0;

   l:= Trunc(Log10(n) + 1);
   showmessage(IntToStr(l));
   if l=2 then
    begin
      final:= 0;
      edit2.text:= IntToStr(final)+ ' : el resultado es ';

    end else begin
   if l >=3 then
    begin
    n:= n div 10;
    while n>0 do
    begin
     num:= n mod 10 ;
     acu:= acu * 10 + num;
     n:= n div 10;
    end;
    acu:= acu div 10;
    showmessage(IntToStr(acu));
    while acu>0 do
    begin
      num:= acu mod 10;
      final:= final * 10 + num;
      acu:=acu div 10;

      edit2.text:=IntToStr(final)+ ' :  el numero sin el primer y ultimo digito'  ;
    end;
    end;
    end;

end;

///pares
procedure TForm1.au71Click(Sender: TObject);
var pares,num:integer;
begin
 pares :=0;
  while n>0 do
  begin
    num:= n mod 10 ;
     if num mod 2 = 0 then
      begin
       pares:= pares * 10 + num;
      end;
      n:=n div 10 ;
      showmessage(IntToStr(pares));
  end;
end;

/////indices de numeros
procedure TForm1.au81Click(Sender: TObject);
var c,num,indice:integer;

begin
 c:=1;indice:=0;
     while n>0 do
     begin
      num:= n mod 10;
      if c mod 2>0 then
      begin
       indice:= indice * 10 + (n mod 10);
      end;
      c:=c+1;
      n:= n div 10 ;
      showmessage(IntToStr(indice));
     end;
end;

{procedure TForm1.au41Click(Sender: TObject);
var
  i: Integer;
  cad, modi: string;
begin
  // Asignamos la cadena de entrada desde Edit1 (puedes cambiarlo seg�n necesites)
  cad := Edit1.Text;

  modi := ''; // Inicializamos la cadena de salida
  i := 1;     // Inicializamos el �ndice

  // Recorremos la cadena de texto
  while i <= Length(cad) do
  begin
    // Si el car�cter actual no es un espacio y es el inicio de una palabra
    if (cad[i] <> ' ') and ((i = 1) or (cad[i - 1] = ' ')) then
    begin
      // Convertimos la primera letra de la palabra a may�scula
      modi := modi + UpCase(cad[i]);
    end
    else
    begin
      // Caso contrario, agregamos el car�cter tal como est�
      modi := modi + cad[i];
    end;

    // Incrementamos el �ndice
    Inc(i);
  end;

  // Mostramos el resultado en Edit2
  Edit2.Text := modi;
end;
}
procedure TForm1.autodidacta2Click(Sender: TObject);
 var acu:string;
      i,j:byte;
begin
   acu:=''; i:=1; j:=1;
     for i := n downto 1 do
       begin
          acu:= acu + cad[i]
       end;
       edit3.text :=  acu;
end;


procedure TForm1.buscarCHARintroducidoYMOTRARcuantasVserepite1Click( Sender: TObject);
 var x: string;
     i,conchar:byte;
begin
  x:= Inputbox('ingresar  un caracter','ingresar solo un caracter','');
  i:=1; conchar:=0;
   while i<= length(cad) do
    begin
       if x = cad[i] then
        begin
          conchar:= conchar + 1;
        end;
      i:= i+1;
    end;
     edit2.text:= IntToStr(conchar) + ' :  es la cantidad de veces que esta el el caracter en la cadena' ;
end;

procedure TForm1.Button1Click(Sender: TObject);
begin
 n:= StrToInt(edit1.text);
 showmessage('numero registrado : '+ IntToStr(n));
   edit1.Clear;
end;

//registrar cadena
procedure TForm1.Button2Click(Sender: TObject);
begin
 cad:= edit1.Text;
 showmessage('cadena registrada : ' + cad);
 //cad2:=edit2.Text;
 //showmessage('cadena  registrada : '+ cad2);
 //car:=edit1.Text[1];
//showmessage('caracter registrado : ' + car);
end;

//procedimiento de longuitud
procedure TForm1.Button3Click(Sender: TObject);
begin
cad:= edit1.Text;
  n:= length(cad);
  edit3.text:='longuitud de cadena : ' + IntToStr( n);
 { edit3.Clear;
  cad2:=edit2.Text;
  lon:=length(cad2);
  edit3.Text:= 'longuitud de cadena ' + IntToStr(lon) ;  }
end;

//verificar si la parte izquierda de un numero es capicua
procedure TForm1.capicuaIZQUI1Click(Sender: TObject);
var num,mitad,origi,comparar,inv,lon,final:integer;

begin
  mitad:=0;origi:=0;comparar:=0;inv:=0;  final:=0;
  lon:= trunc(log10(n)+1);
  if lon mod 2 >0 then
  begin
      while n > 0 do
      begin
        num:= n mod 10;
        inv:= inv * 10 + num;
        n := n div 10;
      end;
    mitad:= (lon+1) div 2 ;
    while  trunc(log10(inv)+1)>mitad do
    begin
      num:= inv mod 10 ;
      origi:= origi *10 + num;
      inv:= inv div 10;
    end;
    comparar := origi;
     while origi > 0 do
      begin
        num:= origi mod 10;
        final:= final * 10 + num;
        origi:= origi div 10 ;
      end;
      if comparar = final then
      begin
        edit2.Text:= IntToStr(final)+' :  es capicua';
      end else begin
        edit2.Text:= IntToStr(final)+' :  no  es capicua';
      end;
  end else begin
     edit2.Text:= ' mejorar el algoritmo, par dos numeros que sean centro';
  end;
end;

procedure TForm1.chat102Click(Sender: TObject);
var n,c:integer ;
    fac:int64;
 begin
     fac := 1; // Factorial inicializado en 1 (caso base)
  c := 1;   // Contador inicializado en 1
  // Calcular el factorial usando un bucle while
  while c <= n do
  begin
    fac := fac * c; // Multiplicamos el valor actual del factorial por el contador
    Inc(c);         // Incrementamos el contador
  end;
 end;




procedure TForm1.chat1Click(Sender: TObject);
begin

end;

//chat11
procedure TForm1.chat21Click(Sender: TObject);
begin
 // edit3.Text:= BoolToStr(esvocal(cad,car),true);
 //edit3.Text:= BoolToStr(espacioblanco(cad,car),true);
 edit3.Text:= BoolToStr(esnumero(cad,car),true);
end;

 //chat1
procedure TForm1.chat2Click(Sender: TObject);

var
  inputString: String;  // Cadena de entrada
  chars: array of Char; // Arreglo din�mico para almacenar los caracteres
  i: Integer;           // Variable de �ndice para el ciclo while
begin
  // Asignamos la cadena de entrada
  inputString := cad;
  // Inicializamos el arreglo de acuerdo con la longitud de la cadena
  SetLength(chars, Length(inputString));
  // Inicializamos el �ndice
  i := 1;  // El �ndice de la cadena comienza desde 1 (no 0 como los arreglos)
  // Iteramos sobre la cadena usando un ciclo while
  while i <= Length(inputString) do
  begin
    // Almacenamos el car�cter en el arreglo
    chars[i-1] := inputString[i];  // Restamos 1 porque el �ndice del arreglo comienza en 0
    // Incrementamos el �ndice
    Inc(i);
  end;
  // Mostrar los caracteres almacenados en el arreglo
  for i := 0 to High(chars) do
  begin
    ShowMessage('El car�cter en la posici�n ' + IntToStr(i) + ' es: ' + chars[i]);
    //listbox1.Items.Add(invercad(cad));
  end;
end;

//chat3  cortar una palabra
procedure TForm1.chat31Click(Sender: TObject);
var posicion :integer;
begin
  posicion:= pos(cad2,cad);
  listbox1.Items.Add(copy(cad,posicion,length(cad2)));
end;

//chat4
procedure TForm1.chat41Click(Sender: TObject);
var
  i, Posicion: Integer;
  mayus, copia: string;
begin
  mayus := '';
  copia := '';
  i := 1;

  Posicion := Pos(' ', cad);

  if Posicion > 0 then
  begin
    for i := 1 to Posicion - 1 do
      mayus := mayus + UpCase(cad[i]);

    copia := Copy(cad, Posicion, Length(cad)-posicion + 1);
  end
  else
  begin
    mayus := UpperCase(cad);
  end;
   delete(cad,1,Posicion);

  Edit3.Text := mayus + copia;
  listbox1.Items.Add(cad);

end;

//chat5
procedure TForm1.chat51Click(Sender: TObject);
 var posicion:integer;
     original:string;
begin
   original:=cad;
  posicion:= pos(' ',cad);
  delete(cad,posicion ,length(cad));
  showmessage(cad);
   edit3.Text:= StringReplace(original,cad,cad2,[rfReplaceAll]);
end;

//chat6
procedure TForm1.chat61Click(Sender: TObject);
 var caracter:char;
begin

// cad:= InputBox('ingrese un texto','tu nombre es :', '');
    caracter:= edit2.Text[1];
// edit3.Text:= BoolToStr(espalindromo(cad),true);
  //edit3.Text:= 'el numero de vocales es : ' + IntToStr(numvoc(cad));
 // edit3.Text:= 'la cadena modificada es : : ' + (elimvoc(cad));
  edit3.Text:= 'la cadena modificada es : : ' + (cambvoc(cad));
end;

//chat7
procedure TForm1.chat62Click(Sender: TObject);
begin

end;

//chat8
procedure TForm1.CONaMAYUSlosPRIcharDEcadaPAl1Click(Sender: TObject);
var i:byte;
    modi:string;
    sw:boolean;
begin
 i:=1; modi:=''; sw:=true;
 while i<=length(cad) do
  begin
    if( i=1) and (cad[i]<>' ') then
     begin
       modi := modi + upcase( cad[i]);
     end;

     if cad[i]=' ' then
     begin
       modi:= modi + cad[i]+ upcase(cad[i+1]);
       i:=i+1;
       sw:=false;
     end;

      if i>1   then
     begin
       if sw=false then
       begin
         i:=i+1;
         sw:=true;
       end;
       modi:= modi + cad[i]
     end;
     i:=i+1;
  end;
  edit2.Text:= modi + ' : es la palabra modificada';
end;

//chat9
function paryimpar(n:integer): string;
 var num,invertido,a,b,i:integer;
     res:string;
begin
     invertido:=0; res:=''; a:=0; b:=0; i:=0;
    num:= n mod 10 ;

    if num in [2,3,5,7] then
     begin
     a:=a+num;
      i:=i+1;
     end;

    while n>0 do
    begin
     num:= n mod 10 ;
     invertido:= invertido * 10 + num ;
     n:= n div 10;
    end;
     b:= invertido mod 10 ;
    if  b in [2,3,5,7]  then
     begin
       i:=i+1;
     end;
       if i>0 then
        begin
          res:= ('si los digitos son primos');
        end  else begin
          res:= ('no,si los digitos son primos');
        end;
        result:=res;
end;


procedure TForm1.ej11Click(Sender: TObject);
var sd,num,inve,c:integer;
    prom:real;
begin

c:=1; inve:=0;  prom:=0;   sd:=0;
    if c=1 then
     begin
       num:= n mod 10;
       sd:= sd+num;
       c:=c+1;
     end;
     num:=0;
     while n>0 do
     begin
       num:= n mod 10;
       inve:=inve*10 + num ;
       n:=n div 10;
     end;
     num:=0;
     num:= inve mod 10;
     sd:= sd + num;
      prom:= sd / c;
      edit2.Text:= FloatToStr(prom)+ ' : el  promedio del primero y el ultimo es ';
end;

/////factorial 1!+3!+5!....sumar terminos impares
procedure TForm1.ej12Click(Sender: TObject);
var fac:longInt;
    suma,c,con,i,num,sumafac:integer;
begin
   fac:=1; suma:=0; c:=1;  con:=1; i:=1; sumafac:=0;
    while c<=n  do
    begin
     while i<= con do
     begin
       fac:= fac * i;
       i:=i+1;
     end;
     while fac>0 do
     begin
       num:= fac mod 10 ;
       sumafac:= sumafac + num;
       fac:= fac  div 10;
     end;
      if sumafac mod 2 >0 then
      begin
        suma:= suma + sumafac;

      end;
        fac:=1;
        i:=1;
       sumafac:=0;
       con:= con + 2;
     c:=c+1;
    end;
      edit2.Text:= IntToStr(suma);
end;

procedure TForm1.ej13Click(Sender: TObject);
var
  c, i, j, k, palcan, n: Integer;
  car1, car2: string;
  esVocalInicial, tieneVocalesSeguidas: Boolean;
begin
  c := 0;
  i := 1;
  palcan := 0;
  n := Length(cad);

  while i <= n do
  begin
    if (i = 1) or (cad[i - 1] = ' ') then
    begin
      if cad[i] in ['a', 'e', 'i', 'o', 'u'] then
        esVocalInicial := True
      else
        esVocalInicial := False;
    end;

    tieneVocalesSeguidas := False;
    if esVocalInicial then
    begin
      k := i + 1;
      j := i;
      while (j <= n) and (cad[j] <> ' ') do
      begin
        if (k <= n) and (cad[j] in ['a', 'e', 'i', 'o', 'u']) and (cad[k] in ['a', 'e', 'i', 'o', 'u']) then
        begin
          tieneVocalesSeguidas := True;

        end;
        Inc(k);
        Inc(j);
      end;
      if tieneVocalesSeguidas then
        Inc(palcan);
    end;
    while (i <= n) and (cad[i] <> ' ') do
      Inc(i);
    Inc(i);
  end;

  Edit2.Text := IntToStr(palcan) + ' : es la cantidad de palabras que comienzan en vocal y tienen vocales juntas';
end;


procedure TForm1.ej31Click(Sender: TObject);
var  primo,indice,num:integer;
begin
indice:=0;
primo:=0;
   while n>0 do
    begin
     indice:=indice+1;
     num:= n mod 10;
  if ((num) in [2,3,5,7]) AND (indice mod 2 = 0 )then
      begin
       primo:= primo*10+ num;
      end;
      n := n div 10;
    end;
    edit2.Text:=IntToStr(primo)+ ': el numero primo es';
end;

procedure TForm1.ejercicio21Click(Sender: TObject);
 var modi,a,b:string;
     posicion,posicion1:integer;
begin
 a:=''; b:='';

  posicion:=pos(' ', cad );
  posicion1:=posex(' ',cad,posicion+1);
 modi:= copy(cad,posicion1,length(cad));

  showmessage(modi);

  showmessage(IntToStr(posicion));
  showmessage(IntToStr(posicion1));
   for i := posicion-1 downto 1 do
   begin
    a:=a+cad[i] ;
   end;
   showmessage(a);

   for i := posicion1-1 downto 1 do
     begin
       b:=b+ cad[i];
     end;
     showmessage(b);
     edit2.Text:= a  +  b +  modi;
end;

////ejercicio4
procedure TForm1.ejerciciofinal31Click(Sender: TObject);
var smayor, nume,suma,num,c,x,cn:integer;
     prom:real;
begin
 c:=1;nume:=0; smayor:=0;  suma:=0;  num:=0; x:=0; cn:=0;
  while c<=n do
  begin
   num:= StrToInt(InputBox('ingrese un numero','ingrese un numero',''));
    if num>x then
     begin
       x:= num;
       suma:=suma+x;
       cn:=cn+1;
     end;

    c:=c+1;
  end;
   prom:= suma / cn;
     edit2.Text:=FloatToStr(prom)+': es el promedio';
end;


procedure TForm1.ejerciciofinal32Click(Sender: TObject);
var modi,inver:string;
    i,x,y,z,k:byte;
begin
   i:=1; k:=1;
   while i<=length(cad) do
    begin
      if (i=1) and(cad[i]<>' ') and not(cad[i]in['a','e','i','o','u']) then
      begin
       x:= i;
      end;

      if cad[i]=' ' then
      begin
       x:=i;
       k:=i+1;
        if not(cad[i+1]in ['a','e','i','o','u']) then
          while cad[k]<>' ' do
          begin
            modi:= modi+cad[k];
            inver:= inver+ invertircadena(modi);
           k:=k+1;
          end;
          K:=0;
      end;
       k:=x+1;
       if not(cad[k]in ['a','e','i','o','u']) then
         begin
          while k<= length(cad) do
          begin
            modi:= modi+cad[k];
            inver:= inver+ invertircadena(modi);
           k:=k+1;
          end;
         end;
      i:=i+1;
    end;
    edit2.Text:= inver;
end;

procedure TForm1.ejerciofinal11Click(Sender: TObject);
var
  x, e, c, n: Integer;
  mult: Integer;
  suma, exp,fac: Double;
begin
   n := StrToInt(InputBox('Ingrese un n�mero', 'Cantidad de t�rminos n:', ''));
   x := StrToInt(InputBox('Ingrese un n�mero', 'Base para x:', ''));

  e := 0; c := 1;  suma := 0;

  while c <= n do
  begin
    if c = 1 then
    begin
      exp := x;
      fac := 1.0;
      suma := exp / fac;
    end
    else
    begin
      exp := Power(x, c);
      fac := 1.0;
      for mult := 1 to c do
        fac := fac * mult;

      suma := suma + (exp / fac);
    end;

    c := c + 2;
  end;

  Edit2.Text := FloatToStr(suma)+ ' es el promedio de la suma ';

end;
 ////terminado
procedure TForm1.ejerciofinal12Click(Sender: TObject);
begin
var menor,mayor,num:integer;

begin
menor:=0; mayor:=0; num:=0;
     while n>0 do
     begin
       num:= n mod 10;
       if num < 6 then
       begin
        menor:=menor*10 + num;
       end else begin
        if num>=6 then
        begin
          mayor := mayor*10+num;
        end;
       end;
       n:= n div 10;
        showmessage(IntToStr(mayor)+': el mayor es');
        showmessage(IntToStr(menor)+': el menor es ') ;
     end;
     edit2.Text:= (IntToStr(mayor)+': mayores e iguales a 6....')+(IntToStr(menor)+ ': son menores a 6');
end;

end;

////eliminar consonates ultima palabra
procedure TForm1.ELIMconsoULTpal1Click(Sender: TObject);
var x,i:byte;
    modi:string;
begin
    x:=0; i:=1; modi:='';
    while i<=length(cad) do
     begin
        if cad[i]=' ' then
         begin
         x:=i;
         end;
     i:=i+1;
     end;
     i:=1;
     while i<=length(cad) do
     begin
       if (i>x)AND (cad[i] in ['a','e','i','o','u']) then
        begin
         modi:=modi+ cad[i];
        end else begin
          if (i>x)AND NOT(cad[i] in ['a','e','i','o','u']) then
          begin
          modi:=modi+'';
          end;
        end;
        if i<=x then
        begin
        modi:= modi + cad[i];
        end;
       i:=i+1;
     end;
     edit2.Text:= modi + ' : es la cadena modificada';
end;

procedure TForm1.elimPAlqueCOMenC1Click(Sender: TObject);
var  i,j:byte;
     modi:string;
begin
 i:=1; j:=0;modi:='';
 while i<= length(cad) do
 begin
  if(i=1) and (cad[i]<>' ') and (cad[i]<>'c') then
  begin
    modi:= modi+ cad[i];
  end;
    if (i=1) and (cad[i]= 'c') then
    begin
     j:=i;
      while cad[j]<>' ' do
       begin
         j:=j +1;
       end;
       i:=j;
    end;

  if( cad[i] = ' ') and (cad[i+1]= 'c') then
   begin
     j:=i+1;
      while cad[j]<>' ' do
       begin
         j:=j +1;
       end;
       i:=j;
   end;
   if i>1 then
   begin
     modi:= modi + cad[i];
   end;
   i:=i+1;
 end;
   edit2.Text:=modi +' : es la palabra modifiada';
end;

procedure TForm1.espalabra2Click(Sender: TObject);
var espacio:string;
    x:boolean;
begin
    espacio:=' ';
    x:=true;
    if espacio= cad[1] then
     begin
       edit2.text:= 'es espacio ';
     end else begin
       edit2.text:= '  no es espacio ';
     end;
end;

procedure TForm1.examen2Click(Sender: TObject);

begin
 edit2.Text:= (paryimpar(n));
end;

procedure TForm1.insertarSUBcadapartirDElaSEGpal1Click(Sender: TObject);
var x,completa:string;
    i,j,k,z:byte;
begin
  x:= inputbox('ingrese una subcadena ','para ingresar a partir de la segunda pal','');
   j:=1; i:=1; k:=1; z:=1;
   completa:='';
   while cad[j]<>' ' do
    begin
       j:= j +1;
    end;
   // z:= j;
    //j:=1;
    while i<= length(cad) do
     begin
         while (i > j)  AND (k<=length(x)) do
           begin
           completa:= completa + x[k];
            k:=k+1;
            if k -1 = length(x) then
             begin
               completa:=completa + ' ';
             end;

           end;
       completa:=completa + cad[i];
       i:=i +1;
     end;
      edit2.Text:= completa + ' : es la cadena completa' ;
end;

//procedimiento borrar
procedure TForm1.limpiezaClick(Sender: TObject);
begin
edit1.Clear;
edit2.Clear;
edit3.Clear;
listbox1.Clear;
end;

////mod2 examen
procedure TForm1.miercoles2Click(Sender: TObject);
var num,menor:integer;
begin
   menor:=9;
   while n>0 do
   begin
     num:= n mod 10;
      if menor>num then
       begin
         menor:=num;
       end;
       n:= n div 10;
   end;
    edit2.text:= IntToStr(menor)+' : el numero menor es';
end;


/// serie: 3 + 18 + 53
procedure TForm1.mod101Click(Sender: TObject);
var a,b,c,suma:integer;
    sw:boolean;
begin
   a:=1; b:=3; sw:=true; suma:=0; c:=1;
   while c<=n do
   begin

        suma:=suma+ (a*b);
        b:=b+2;
       a:=a+2;

      c:=c+1;

      showmessage(IntToStr(suma));
   end;
end;

procedure TForm1.mod111Click(Sender: TObject);
var
l,i,j,m,k,s:byte;
x,x1,x2,c:cardinal;
begin
   x:= strtoint(edit1.Text);
   l:=trunc(log10(x)+1);
   i:=1;s:=0;
   while i<=l do begin
      k:=((x div(trunc(power(10,i-1)))) mod 10);
      j:=i+1;
      while j<=l do begin
         m:= ((x div(trunc(power(10,j-1)))) mod 10);
         if k = m  then begin
            c:=trunc(power(10,j-1));
            x1:=((x div c)div 10);
            x2:=x mod c;
            x:=x1*c+x2;
            l:=trunc(log10(x)+1);
            s:=s+1;
         end;
         j:=j+1;
      end;
      if s>0 then begin
         c:= trunc(power(10,i-1));
         x1:=((x div c)div 10);
         x2:=x mod c;
         x:=x1*c+x2;
         l:=trunc(log10(x)+1);
         s:=0;
      end;
      i:=i+1;
   end;
   edit2.Text:=IntToStr(x);
end;

procedure TForm1.mod21Click(Sender: TObject);
  var c,num,suma1,suma,numero:integer;
    x:string;
begin
 c:=1; num:=0; suma1:=0; suma:=0;
     while c<=n do
     begin
      numero:=StrToInt(InputBox('ingrese un numero','ingrese un numero',''));
      showmessage(IntToStr(numero)+ ': numero registrado');
      while numero>0 do
      begin
      num:= numero mod 10 ;
      suma1:= suma1 + num;
       numero := numero div 10 ;
      end;
      if suma1 mod 2 > 0 then
      begin
        suma:= suma + suma1;
      end;
      suma1:=0;
      c:=c+1;
     end;
     edit2.Text:=IntToStr(suma);
end;
 procedure TForm1.mod31Click(Sender: TObject);
 var menor,mayor,num:integer;

begin
menor:=0; mayor:=0; num:=0;
     while n>0 do
     begin
       num:= n mod 10;
       if num < 6 then
       begin
        menor:=menor*10 + num;
       end else begin
        if num>=6 then
        begin
          mayor := mayor*10+num;
        end;
       end;
       n:= n div 10;
        showmessage(IntToStr(mayor)+': el mayor es');
        showmessage(IntToStr(menor)+': el menor es ') ;
     end;
     edit2.Text:= (IntToStr(mayor)+': mayores e iguales a 6....')+(IntToStr(menor)+ ': son menores a 6');
end;

//mod5 examen
procedure TForm1.mod41Click(Sender: TObject);
var num1,num2,prueba:integer;
begin
  num1:=  StrToInt(edit1.text);
  showmessage(IntToStr(num1)+ 'primer numero registrado');
  num2:= StrToInt(edit2.text);
  showmessage(IntToStr(num2)+'segundo numero registrado');
  prueba:= num1 mod num2 ;
  showmessage(IntToStr(prueba)+ ': num1 mod num1');
    if num1>num2 then
    begin
      while num1>0 do
      begin
        num1:=num1 - num2;
        showmessage(IntToStr(num1));
      end;


    end else begin
     showmessage('error,el primer numero es menor al segundo');
     showmessage('ingrese el primer numero ,mayor al segundo');
    end;
    edit2.Text:= IntToStr(num1) + '  :el resultado de la divisio sucesiva es ';
end;

///mod4 examen
procedure TForm1.mod42Click(Sender: TObject);
 var n,lon,num:integer;
   modificada,x:string;
    termino:integer;
begin
  n:=length(cad);  modificada:=''; x:='';
  if n mod 2 = 0 then
  begin
   termino:= n div 2 ;
   for i := termino-1 downto 1 do
   begin
     modificada:=modificada+ cad[i];
   end;
    modificada:= modificada + cad[termino];
    modificada:= modificada + cad[termino+1];
   x:= copy(cad,(n div 2)+2,n);
    lon:= length(x);
    for i := lon downto 1 do
    begin
       modificada:= modificada + x[i];
    end;
     showmessage(modificada) ;
  end else begin
   termino:= (n+1)div 2;
    for i := (termino)-1 downto 1 do
    begin
      modificada:= modificada + cad[i];
    end;
    modificada:=modificada+ cad[termino];
    x:=copy(cad,termino+1,n);
    lon:=length(x);
    for i := lon  downto 1 do
    begin
      modificada:=modificada +  x[i];
    end;
     edit2.Text:= modificada;
  end;
end;

/// sumatoria hasta que suma sea igual a n , luego mostar cantidad de pares e impares
procedure TForm1.mod61Click(Sender: TObject);
 var  suma,par,impar,num:integer;
begin
    suma:=0; par:=0; impar:=0;
   while suma<=n do
    begin
      num := StrToInt(inputbox('ingrese un numero','se sumara este numero',''));
      if suma + num < n then
      begin
      if num mod 2 >0 then
       begin
         impar:=impar + 1;
       end else begin
         if num mod 2 = 0 then
           begin
             par:=par + 1;
           end;
       end;
      end;
       suma:= suma + num;
    end;

    edit2.Text:= IntToStr(par)+ ' : la cantidad de numeros pares es ';
     edit3.Text:= IntToStr(impar)+ ' : la cantidad de numeros impares es ';
end;

procedure TForm1.mod62Click(Sender: TObject);
begin

end;

//// sumar los digitos de los n numero ingresados y mostrar la suma de los digitos mas grnades
procedure TForm1.mod71Click(Sender: TObject);
var smayor, nume,suma,num,c:integer;
begin
 c:=1;nume:=0; smayor:=0;  suma:=0;  num:=0;
  while c<=n do
  begin
    num:= StrToInt(InputBox('ingrese un numero','ingrese un numero',''));
    while num>0 do
    begin
      nume:= num mod 10;
      suma:= suma + nume;
      num:= num div 10 ;
    end;
    showmessage(IntToStr(suma));
    if suma>smayor then
     begin
       smayor:=suma;

     end;
     suma:=0;
    c:=c+1;
  end;
  edit2.Text:=IntToStr(smayor);
end;

///mod8 examen
procedure TForm1.mod81Click(Sender: TObject);
var num,fac,fac1,c,a:integer;
    suma:real;
     sw:boolean;
begin
 c:=1; num:=4; fac:=1; suma:=0; sw:=true; fac1:=3; a:=1;
  fac:=fac*c;
  while c<=n do
  begin
      suma:= suma +( num/ fac );
      for a := 1 to fac1 do
      begin
        fac:=fac*a;
      end;
      a:=1;
      fac1:=fac1+1;
    if sw=true then
     begin
      num:=num*3;
      sw:=false;
     end else begin
      num:= num+2;
      sw:=true;
     end;
    c:=c+1;
  end;
  edit2.Text:= FloatToStr(suma);
end;

///mod9  hola mundo de cadena
procedure TForm1.mod91Click(Sender: TObject);
var
sw,i,j,x:byte;
l:string;
p:char;
begin
i:=1;
x:=0;sw:=1;
while i<=Length(cad) do begin
   if sw>1 then begin
   sw:=1;
   x:=i-1;
   end;
   if cad[i]=' ' then begin
      if cad[i-1]='a' then begin
         j:=i-1;
         while j>x do begin
            p:=cad[j];
            l:=UpCase(p);
            p:=l[1];
            cad[j]:=p;
            j:=j-1;
         end;
      end else begin
      sw:=2;
      end;
   end;
   i:=i+1;
end;
if cad[length(cad)]= 'a' then begin
   x:=x+1;
   while x<=length(cad) do begin
      p:=cad[x];
      l:=UpCase(p);
      p:=l[1];
      cad[x]:=p;
      x:=x+1;
   end;
end;
 edit2.text:=cad;
end;
////mod1  examen
procedure TForm1.modelodeexamen2Click(Sender: TObject);
 var fibo,f1,f2, c,fac,fac1,a:integer;
   suma:real;
begin
    c:=1; fac:=1;fac1:=1; a:=1; fibo:=0; f1:=-7; f2:=8; suma:=0;
    while c<=n do
    begin
        fibo:=f1+ f2;
        showmessage(IntToStr(fibo)+' : fibo');
       while (a<=fac1)  do
        begin
        fac:=fac*a;
        a:=a+1;
        end;

        a:=1;
          suma:= suma + (fibo / fac) ;
        fac1:=fac1+2;
         f1:=f2;
         f2:=fibo;
      c:=c+1;
    end;
    edit2.Text:=FloatToStr(suma);
end;

procedure TForm1.mostardigitosordenados1Click(Sender: TObject);
var  x,final:integer;
     i,j:byte;
     auxi:char;
    nSTR:string;
begin
    nSTR:= IntToStr(n);
    x:= length(nSTR);
      for i := 1 to  x -1 do
      for j := i+1 to x  do
       begin
         if nSTR[i]>nSTR[j] then
          begin
            auxi:=nSTR[i];
            nSTR[i]:=nSTR[j];
            nSTR[j]:=auxi;

          end;
       end;
        final:= StrToInt(nSTR);
       edit2.Text:= IntToSTR(final)+ ' : es el numero ordenado';

end;

procedure TForm1.mostrarCARenidnePAR1Click(Sender: TObject);
 var i:byte;
     caracteres:string;
begin
 i:=1;  caracteres:='';
     while i<= length(cad) do
     begin
        if i mod 2=0 then
        begin
          caracteres:= caracteres + cad[i]+ ' ';
        end;
       i:=i +1;
     end;
      edit2.Text:= caracteres + ' : son los caracteres en indice par' ;
end;

procedure TForm1.N1j31Click(Sender: TObject);
begin

end;

///ordenar la palabra que comienza en vocal de forma ascendente
procedure TForm1.ordDEASC2pal1Click(Sender: TObject);
var modi:string;
     auxi:char;
     j:byte;
     i,posicion,posicion1:integer;
begin
   modi:='';
     posicion:=pos(' ',cad);
     posicion1:=posex(' ',cad,posicion+1);
     edit2.Text:= IntToStr(posicion1);
     for i := posicion+1 to posicion1-1 do
      for j := i+1 to posicion1-1  do
       begin
         if cad[i]>cad[j] then
          begin
            auxi:=cad[i];
            cad[i]:=cad[j];
            cad[j]:=auxi;

          end;
       end;
      modi:= copy(cad,posicion ,posicion1-3)  ;
     edit2.Text:=modi + ' : la segunda palabra ordenada de forma ascendente es ';
end;

procedure TForm1.ordenarMODburbuja1Click(Sender: TObject);
var auxi:char; // string
   j:byte;
  i: Integer;
begin
    for i := 1 to n-1 do
     for j := i+1 to n do
      begin
         if cad[i]> cad[j] then
         begin
           auxi:=cad[i];
           cad[i]:= cad[j];
           cad[j]:= auxi;
         end;
      end;
     edit2.text:= cad;
end;

procedure TForm1.potencia1Click(Sender: TObject);
function Potencia(base, exponente: Integer): Int64;
var
  i: Integer;
  resultado: longInt;
begin
  resultado := 1;
  for i := 1 to exponente do
  begin
    resultado := resultado * base;
  end;
  Result := resultado;
end;

 var exponente , base,pote:integer;
begin
   base:= StrToInt(inputbox('ingrese la base','',''));
   exponente:=StrToInt(inputbox('ingrese el exponente','',''));
    pote:= potencia(base,exponente);
    edit2.Text:= IntToStr(pote)+ ' :  la potencia ';
end;

procedure TForm1.serie1112221Click(Sender: TObject);
var i,c:integer;
    suma,expo,fac,b:LongInt;
begin
  i:=1; c:= 1; fac:=1;expo:=0;b:=1;
   while i<=n do
   begin
    while c<=b do
     begin
       fac:= fac * c;
       c:=c+1;
     end;
     expo:= trunc(power(b,b));
     suma:= suma + (expo * fac);
     fac:=1;
     c:=1;
     b:=b+1;
     i:=i+1;
   end;
   edit2.Text:= IntToStr(suma)+ ' : la suma de la serie es';
end;

//////elaavorar una funcion para que dado x y n ,calcular la sumattoria
procedure TForm1.serie202112331Click(Sender: TObject);
var
  x, e, c, n: Integer;
  mult: Integer;
  suma, exp,fac: Double;
begin
   n := StrToInt(InputBox('Ingrese un n�mero', 'Cantidad de t�rminos n:', ''));
   x := StrToInt(InputBox('Ingrese un n�mero', 'Base para x:', ''));

  e := 0; c := 1;  suma := 0;

  while c <= n do
  begin
    if c = 1 then
    begin
      exp := x;
      fac := 1.0;
      suma := exp / fac;
    end
    else
    begin
      exp := Power(x, c);
      fac := 1.0;
      for mult := 1 to c do
        fac := fac * mult;

      suma := suma + (exp / fac);
    end;

    c := c + 1;
  end;

  Edit2.Text := FloatToStr(suma);

end;

procedure TForm1.sumaDGcentro1Click(Sender: TObject);
var lon,num,sd,c1,c2,i:integer;
begin
  lon:=trunc(log10(n)+1); i:=0;
  if lon mod 2 = 0 then
  begin
   c1:= lon div 2;
   c2:= c1+1;
   while n >0 do
   begin
     num:=n mod 10;
     i:=i+1;
     if (i=c1) OR (i=c2) then
     begin
       sd:= sd+num;
     end;
     n:= n div 10;
   end;
  end ;
  edit2.Text:= IntToStr(sd)+ ' : la suma de los terminos centrales es ';
end;

procedure TForm1.sumaDGcentro2Click(Sender: TObject);
var
  nStr, ordenado, nuevoStr: string;  menor: Char; i: Integer; encontrado: Boolean;
begin
  nStr := IntToStr(n); ordenado := '';
  while Length(nStr) > 0 do
  begin
    menor := '9';
    for i := 1 to Length(nStr) do
    begin
      if nStr[i] < menor then
        menor := nStr[i];
    end;
    ordenado := ordenado + menor;

    encontrado := False;
    nuevoStr := '';

    for i := 1 to Length(nStr) do
    begin
      if (nStr[i] = menor) and not encontrado then
      begin
        encontrado := True;
      end
      else
      begin
        nuevoStr := nuevoStr + nStr[i];
      end;
    end;

    nStr := nuevoStr;
  end;

  Edit2.Text := ordenado;
end;

procedure TForm1.sumarDGprimosSELOSN1Click(Sender: TObject);
var c,num,x,suma:integer;
begin
    c:=1;x:=0; suma:=0;
    while c<=n do
    begin
      x:= StrToInt(inputbox('ingrese un numero','para x',''));
      while x>0 do
      begin
        num:= x mod 10 ;
        if num in [2,3,5,7] then
         begin
           suma := suma + num;
         end;
       x:=x div 10;
      end;
      c:=c+1;
    end;
    edit2.Text:= IntToStr(suma)+ ' : es la suma de los digitos primos';
end;

{1) Convertir a may�sculas toda las palabras que comienzan en consonantes.

Ejemplo: cad:='Esta cadena tiene acento'

Mostrar cad:='Esta CADENA TIENE acento'   }
procedure TForm1.tarea11Click(Sender: TObject);
var modi:string;
     sw:boolean;
     i:byte;
begin
// edit2.Text:= invercad(cad)+ ' : es la cadena invertida' ;
// edit2.Text:= invertircadena(cad)+ ' : es la cadena invertida' ;
//  edit2.Text:= elimvoc(cad)+' : elimina vocales' ;
 //  edit2.Text:= IntToStr(numvoc(cad))+ ' : es la cantidad de vocales' ;
    edit2.Text:= BoolToStr(caracterempieza(cad),true)+ ' : verfica si empieza con ese caracter';

end;

{2) Invertir la segunda palabra de la cadena

Registrar

 cad='esta cadena es corta'
 Mostrar

cad='esta anedac es corta'

 }
procedure TForm1.tarea12Click(Sender: TObject);
 var modificada,palabra:string;
   a,posicion,posicion1,i:integer;
begin
 modificada:=''; a:=0; i:=1;
   posicion:= pos(' ',cad);
   showmessage('la posicion one : '+ IntToStr(posicion));
   posicion1 := PosEx(' ', cad, posicion + 1);
   if posicion1 = 0 then
    posicion1 := Length(cad) + 1;
   showmessage('la posicion fue  : '+ IntToStr(posicion1));
   palabra:=copy(cad, posicion + 1, posicion1 - posicion - 1);
     palabra:= System.StrUtils.ReverseString(palabra);
   showmessage(palabra);
   modificada:= ( copy(cad,1,posicion-1)+' ') +(palabra +' ') +( copy(cad,posicion1+1,n));
   edit3.Text:= modificada;
  end;


procedure TForm1.tarea1Click(Sender: TObject);
begin

end;

{3) Eliminar las 2 ultimas palabra de la cadena

cad='Esta cadena es muy larga'

Mostrar: cad='Esta cadena es'}


procedure TForm1.tarea31Click(Sender: TObject);
var modificada:string;
     c,i,posicion,posicion1:integer;
begin
  // Encontrar la posici�n del �ltimo espacio
  posicion := LastDelimiter(' ', cad);
  // Verificar que se haya encontrado al menos un espacio
  if posicion > 0 then
  begin
    // Encontrar la posici�n del pen�ltimo espacio
    LastDelimiter(' ', Copy(cad, 1, posicion - 1));
    // Si encontramos un pen�ltimo espacio, hacemos el 'Copy'
    if posicion1 > 0 then
      modificada := Copy(cad, 1, posicion1 - 1)
    else
      modificada := '';  // Si no hay dos palabras, dejamos una cadena vac�a
  end
  else
    modificada := '';  // Si no hay espacios, dejamos una cadena vac�a
  // Asignar el resultado al componente Edit1
  Edit3.Text := modificada;

end;

procedure TForm1.tareafinal11Click(Sender: TObject);
var fac:longint;
  x,c,i:integer;
  b,e:byte;
  cuadra,suma: single;
begin
 fac:=1; c:=1; i:=1; x:=1; cuadra:=0; suma:=0;  b:=1; e:=2;
 while i<=n do
 begin
  while c<=x do
  begin
    fac:= fac * c;
    c:=c+1;
  end;
  c:=1;
  x:=x+1;
  cuadra:= power(b,e);
  suma:= suma + (fac*cuadra);
  fac:=1;
  b:=b+1;
   i:=i+1;
 end;
  edit2.Text:=FloatToStr(suma)+ ' : es la suma de los n terminos ';
end;

procedure TForm1.tareafinal21Click(Sender: TObject);
var num,nult,npri, inv,lon,x:integer;
    sumaprom:real;
    nSTR:string;
begin
inv:=0; nult:=0; lon:=0; sumaprom:=0;
    nult:= n mod 10;
    while n>0 do
    begin
     num:= n mod 10;
     inv:= inv*10 + num;
     n:= n div 10;
    end;
    npri:= inv mod 10;
    nSTR:= IntToStr(inv);
    lon:= length(nSTR);
    if lon mod 2 >0  then
    begin
     x:=( lon+1) div 2;
    end;
    sumaprom:=( sumaprom + nult+npri + StrToInt(nSTr[x]))/3;
    edit2.Text:= FloatToStr(sumaprom)+ ' : es el promedio del primer,ultimo y termino medio' ;
end;

procedure TForm1.tareafinal31Click(Sender: TObject);
var posicion:integer;
    i,j:byte;
    auxi:char;
begin
posicion:=0; i:=1; j:=2;
 posicion:=Pos(' ', cad) ;

 while cad[i] < cad[j] do
 begin
   for i := 1 to  posicion -2 do
      for j := i+1 to posicion-1  do
       begin
          if cad[i]< cad[j] then
           begin
           auxi:= cad[i];
           cad[i]:= cad[j];
           cad[j]:= auxi;
           end;
       end;
 end;

 edit2.Text:= copy(cad,1,posicion-1) + ' : es la cadena modificada';
end;

end.
