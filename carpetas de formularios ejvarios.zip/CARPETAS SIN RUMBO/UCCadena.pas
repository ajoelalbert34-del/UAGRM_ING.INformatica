unit UCCadena;

interface
Uses SysUtils,UCNumero;
Const
    MaxC=2048;
    Separadores = [' ',',',';','.'];
    AlfaNumSib = ['A'..'Z','a'..'z','0'..'9','/','&'];
Type
    Cadena = Class
      Private
        Longitud : Word;
        Caracteres : Array[1..maxC] of Char;
      Public
        Function getLong:Word;
        Function getChar(i:Word):Char;
        Function getStr:String;
        Procedure addChar(c:Char);
        Procedure addStr(s:String);
        Procedure delChar(i:word);
        Procedure insChar(i:word;c:Char);
        Procedure modChar(i:word;c:char);
        Procedure Delallchar(c : Char);
        Procedure TrnsMayus();
        function countword:word;
        function nextword(var i : word): string;
        function getcharcount(c : Char): byte;
        Function getVowels:Word;
        Function Getpos(c :Char): Byte;

        Function findnumword(p:String):word;
        Procedure delword(p: string);

        procedure insWord(s: string; p: word);
        procedure insWordPal(s: string; p: word);

        function mayorword(d:byte):string;

    End;

implementation

{ Cadena }

procedure Cadena.addChar(c: Char);
begin
     Longitud:=Longitud+1;
     Caracteres[Longitud]:=c;
end;

procedure Cadena.addStr(s: String);
Var
  i : Word;
begin
     Longitud:=Length(s);
     for I := 1 to Longitud do
        Caracteres[i]:=s[i];
end;

function Cadena.countword: word;
var
   i,c : Byte;
begin
     i:=1; c:=0;
     while (i<longitud) do
     begin
          if not(caracteres[i] in separadores) and (caracteres[i+1] in separadores)then c:=c+1;

          i:=i+1;
     end;
     if (caracteres[i] in alfanumsib) then
        c:=c+1;

     result:=c;
end;

procedure Cadena.Delallchar(c: Char);
var
   i : Byte;
begin
   i:=1;
   while i <= longitud do begin
      if getchar(i)=c then begin
      delchar(i);
      end else begin
      i:= i+1;
      end;
   end;
end;

procedure Cadena.delChar(i: word);
var
  J: Word;
begin
     if (i>0)And(i<=Longitud) then
     Begin
         for J := i to Longitud-1 do
          Caracteres[j]:=Caracteres[j+1];
         Longitud:=Longitud-1;
     End
     Else raise Exception.Create('Error, posicion fuera de rango');
end;

procedure Cadena.delword(p: string);
var i, j: word;
begin
     i:=1;
     while not(nextword(i) = p) do begin
     end;
     for j:=1 to length(p) do delchar(i-length(p));

end;



function Cadena.findnumword(p: String): word;
var
   i,s : word;
begin
     i:=1; s:=0;
     while i<=longitud do
     begin
          if (nextword(i) = p) then
          begin
             s:=s+1
          end;
          i:=i+1;
     end;
     result:=s;
end;

function Cadena.getChar(i: Word): Char;
begin
     if (i>0)And(i<=Longitud) then
        Result:=Caracteres[i]
     Else raise Exception.Create('Error, posicion fuera de rango');
end;

function Cadena.getcharcount(c: Char): byte;
var
   i,s : Byte;
begin
     i:=1;
     while i <= longitud do begin
       if getchar(i) = c then
         s:=s+1;
     i:=i+1;
     end;
  result:=s;
end;

function Cadena.getLong: Word;
begin
     Result:=Longitud;
end;

function Cadena.Getpos(c: Char): Byte;
var
   i : Byte;
   pos : Byte;
begin
   i:=1;
   while (i<= longitud) and (pos=0) do begin
     if getchar(i)=c then begin
     pos:= i;
     end;
     i:= i+1;
   end;
   Result:=pos;
end;

function Cadena.getStr: String;
var
  I: Integer;
  s : String;
begin
     s:='';
     for I := 1 to Longitud do
        s:=s+Caracteres[i];
     Result:=s;
end;

function Cadena.getVowels: Word;
var
  I,c: Integer;
begin
     c:=0;
     for I := 1 to Longitud do
        if getChar(i) in ['a','e','i','o','u'] then
           c:=c+1;
     Result:=c;
end;

procedure Cadena.insChar(i: word; c: Char);
var
  J: Word;
begin
     if (i>0)And(i<=Longitud) then
     Begin
          Longitud:=Longitud+1;
          for J :=Longitud Downto i+1 do
              Caracteres[J]:=Caracteres[J-1];
          Caracteres[i]:=c;
     End
     Else raise Exception.Create('Error, posicion fuera de rango');

end;

procedure Cadena.modChar(i: word; c: char);
begin
     if (i>0)And(i<=Longitud) then
        Caracteres[i]:=c
     Else raise Exception.Create('Error, posicion fuera de rango');

end;

function Cadena.nextword(var i: word): string;
var
   p : string;
begin
     while (i<=longitud) and (caracteres[i] in separadores) do
     i:=i+1;
     p:='';
     while (i<=longitud) and (caracteres[i] in alfanumsib) do
     begin
       p:=p+caracteres[i];
       i:=i+1;
     end;
     result:=p;

end;

procedure Cadena.TrnsMayus;
var
  i : Byte;
begin
    i:=1;
    uppercase(getchar(i));
    while i<=longitud do begin
      caracteres[i]:=upcase(caracteres[i]);
      //modchar(i,upcase(getchar(i)));
      i:=i+1;
    end;
end;

procedure Cadena.insWordPal(s: string; p: word);
var i, c, j: word;
begin
  if (p>0) and (p<=countWord) then begin
   i:=1; c:=1;
   while c<>p do begin
      if not (Caracteres[i] in separadores) And (Caracteres[i+1] in separadores)  then c:=c+1;
      i:=i+1;
   end;

   insChar(i, ' ');
   insChar(i, ' ');
   i := i + 1;
   for j := 1 to length(s) do begin
    inschar(i+j, s[j]);
   end;
  end else raise Exception.Create('Error: posicion no valida');
end;

procedure Cadena.insWord(s: string; p: word);
var i: word;
begin
  if (p>0) And (p<=Longitud) then begin
     longitud := longitud + length(s);
     for i := longitud downto p+length(s) do begin
       Caracteres[i]:=Caracteres[i-length(s)];
     end;
     for i := p to p+length(s)-1 do begin
        caracteres[i] := s[i-p+1];
     end;
  end;
end;

function Cadena.mayorword(d: byte): string;
var
a,b,c,sw : byte;
i : Word;
x,w,z: string;
begin
  i:=1;
  x:=nextword(i);
  c:=length(x);
  sw:=0;
    while (i<=longitud) and (sw < d) do begin
      x:= nextword(i);
      a:=length(x);
      if c < a then begin
         c:= a;
         i:=1;
         sw:=sw+1;
      end;
    end;

    result:=x;
end;

end.
