object Form1: TForm1
  Left = 0
  Top = 0
  Caption = 'seriesswitcht'
  ClientHeight = 524
  ClientWidth = 779
  Color = clWhite
  Font.Charset = ANSI_CHARSET
  Font.Color = clBlack
  Font.Height = -16
  Font.Name = 'Segoe UI'
  Font.Style = [fsBold]
  Menu = MainMenu1
  TextHeight = 21
  object Label1: TLabel
    Left = 72
    Top = 51
    Width = 59
    Height = 21
    Caption = 'entrada'
  end
  object Label2: TLabel
    Left = 72
    Top = 112
    Width = 45
    Height = 21
    Caption = 'salida'
  end
  object Label3: TLabel
    Left = 568
    Top = 88
    Width = 59
    Height = 21
    Caption = 'mostrar'
  end
  object Edit1: TEdit
    Left = 168
    Top = 48
    Width = 121
    Height = 29
    TabOrder = 0
    Text = 'Edit1'
  end
  object Edit2: TEdit
    Left = 168
    Top = 104
    Width = 121
    Height = 29
    TabOrder = 1
    Text = 'Edit2'
  end
  object Button1: TButton
    Left = 96
    Top = 368
    Width = 75
    Height = 25
    Caption = 'Limpiar'
    Font.Charset = ANSI_CHARSET
    Font.Color = clNavy
    Font.Height = -16
    Font.Name = 'Segoe UI'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 2
    OnClick = Button1Click
  end
  object ListBox1: TListBox
    Left = 480
    Top = 128
    Width = 241
    Height = 361
    Font.Charset = ANSI_CHARSET
    Font.Color = clBlue
    Font.Height = -16
    Font.Name = 'Segoe UI'
    Font.Style = [fsBold]
    ItemHeight = 21
    ParentFont = False
    TabOrder = 3
  end
  object BitBtn1: TBitBtn
    Left = 288
    Top = 368
    Width = 75
    Height = 25
    Font.Charset = ANSI_CHARSET
    Font.Color = clMenuHighlight
    Font.Height = -16
    Font.Name = 'Segoe UI'
    Font.Style = [fsBold]
    Kind = bkClose
    NumGlyphs = 2
    ParentFont = False
    TabOrder = 4
  end
  object MainMenu1: TMainMenu
    Left = 696
    Top = 40
    object series1: TMenuItem
      Caption = 'series'
      object parimpar1: TMenuItem
        Caption = 'parimpar'
        OnClick = parimpar1Click
      end
      object DobleCuadrado1: TMenuItem
        Caption = 'DobleCuadrado'
        OnClick = DobleCuadrado1Click
      end
      object DobleCuadrado2: TMenuItem
        Caption = 'fibonaccidoble'
        OnClick = DobleCuadrado2Click
      end
      object cuadradomultiplode31: TMenuItem
        Caption = 'cuadradomultiplode3'
        OnClick = cuadradomultiplode31Click
      end
    end
    object switcht1: TMenuItem
      Caption = 'switcht'
    end
  end
end
