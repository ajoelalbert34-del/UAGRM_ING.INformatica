object Form1: TForm1
  Left = 0
  Top = 0
  Caption = 'Form1'
  ClientHeight = 441
  ClientWidth = 624
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = 'Segoe UI'
  Font.Style = []
  PixelsPerInch = 96
  TextHeight = 15
  object crear: TLabel
    Left = 73
    Top = 83
    Width = 26
    Height = 15
    Caption = 'crear'
  end
  object CsmbiarValor: TLabel
    Left = 73
    Top = 165
    Width = 70
    Height = 15
    Caption = 'CsmbiarValor'
  end
  object Edit1: TEdit
    Left = 232
    Top = 80
    Width = 249
    Height = 23
    TabOrder = 0
    Text = 'Edit1'
  end
  object Edit2: TEdit
    Left = 232
    Top = 165
    Width = 249
    Height = 23
    TabOrder = 1
    Text = 'Edit2'
  end
  object BORRAR: TButton
    Left = 208
    Top = 328
    Width = 169
    Height = 25
    Caption = 'BORRAR'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Goudy Stout'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 2
    OnClick = BORRARClick
  end
end
