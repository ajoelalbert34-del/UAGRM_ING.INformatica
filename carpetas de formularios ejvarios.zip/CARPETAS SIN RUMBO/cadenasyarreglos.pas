unit cadenasyarreglos;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.Buttons, Vcl.StdCtrls, Vcl.Menus;

type
  TForm1 = class(TForm)
    MainMenu1: TMainMenu;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Edit1: TEdit;
    Edit2: TEdit;
    Edit3: TEdit;
    Button1: TButton;
    Button2: TButton;
    Button3: TButton;
    ListBox1: TListBox;
    BitBtn1: TBitBtn;
    cadenas11: TMenuItem;
    cadenas12: TMenuItem;
    invertirfisica1: TMenuItem;
    escapicua1: TMenuItem;
    escapicua2: TMenuItem;
    caracIguales1: TMenuItem;
    pruebas1: TMenuItem;
    pruebas2: TMenuItem;
    Button4: TButton;
    examepractico1: TMenuItem;
    examepractico2: TMenuItem;
    ejercicio21: TMenuItem;
    procedure Button3Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure invertirfisica1Click(Sender: TObject);
    procedure cadenas12Click(Sender: TObject);
    procedure escapicua1Click(Sender: TObject);
    procedure escapicua2Click(Sender: TObject);
    procedure caracIguales1Click(Sender: TObject);
    procedure pruebas2Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure examepractico2Click(Sender: TObject);
    procedure ejercicio21Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form1: TForm1;
   n,i:byte;
   cad ,cad2:string;
   car:char;
implementation

{$R *.dfm}
////funciones1
  function esvocal(car:char):boolean;
  var voc:string; sw:boolean;

  begin
    voc:= 'aeiouAEIOU'; sw:=true;
     sw:= pos(car,voc ) > 0;
      result:= sw;
  end;
   function blanco(cad:char ): boolean;
   var espacio:string;
       sw:boolean;
   begin
       espacio:='';
      sw:= pos(espacio,cad)>0;
      result:=sw;
   end;
////FIN de funcione 1

procedure TForm1.Button1Click(Sender: TObject);

begin
 i:=1;
 cad:=edit1.Text;
  showmessage('cadena registrada : ' + cad);
   edit1.clear;
    cad2:=edit2.Text;
  showmessage('cadena registrada : ' + cad2);
   edit2.clear;
  { edit1.Text:=  ('ingrese solo un caracter, que sea vacio');
   cad2:= edit1.Text;
    car:= cad[i];
  showmessage('cadena registrada : ' + cad[i]);
   edit2.clear;
   edit1.clear; }
end;
procedure TForm1.Button2Click(Sender: TObject);
 var n,lon:integer;
begin
n:= length(cad);
edit3.Text:= 'la longuitud es : '+ IntToStr(n);
listbox1.Items.Add('la longuitud es : ' + IntToStr(n));
 lon:= length(cad2);
edit3.Text:= 'la longuitud es : '+ IntToStr(lon);
listbox1.Items.Add('la longuitud es : ' + IntToStr(lon));
end;

procedure TForm1.Button3Click(Sender: TObject);
begin
edit1.clear;
edit2.clear;
edit3.clear;
listbox1.clear;

end;

procedure TForm1.Button4Click(Sender: TObject);
  var car:char;
begin

end;

procedure TForm1.cadenas12Click(Sender: TObject);
var
  i, n: Integer;
  invertida: string;
begin
  n := Length(cad);
  invertida := '';


  for i := n downto 1 do
    invertida := invertida + cad[i];
  Edit3.Text := invertida;
  ListBox1.Items.Add(invertida);

end;

procedure TForm1.caracIguales1Click(Sender: TObject);
var
  vacia: string;
  i, j, n, lon: Integer;
begin

  n := Length(cad);
  lon := Length(cad2);
  vacia := '';
  for i := 1 to n do
  begin
    for j := 1 to lon do
    begin
      if cad[i] = cad2[j] then
      begin
        if Pos(cad[i], vacia) = 0 then
          vacia := vacia + cad[i];
        Break;
      end;
    end;
  end;
  Edit3.Text := vacia;
  ListBox1.Items.Add('Caracteres repetidos: ' + vacia);

end;

procedure TForm1.ejercicio21Click(Sender: TObject);
var  mayus,rest,original:string;
  Posicion,i,c: Integer;
begin
  i:=1;  mayus:='';  c:=0;
      Posicion := Pos(cad2, Cad);
      if Posicion > 0 then begin
            Delete(cad, Posicion, Length(cad2));
           end;
     while i< n do begin

      if cad[i]<> '' then begin
        mayus:=mayus + upcase(cad[i]);
          inc(i);
        end else begin
        break
        end;
       end;

    mayus:= mayus + cad ;
  Edit3.Text := IntToStr(posicion);
  ListBox1.Items.Add('Cadena resultante: ' + Cad);
   ListBox1.Items.Add('pal en mayuscula: ' + mayus)  ;

end;

procedure TForm1.escapicua1Click(Sender: TObject);
var
  i, n: Integer;
  sw: Boolean;
  invertida, original: string;
begin
  original := cad;
  n := Length(cad);
  invertida := '';

  for i := n downto 1 do
    invertida := invertida + cad[i];

  sw := original = invertida;

  Edit3.Text := BoolToStr(sw, True);
  ListBox1.Items.Add('Es capic�a: ' + BoolToStr(sw, True));

end;

procedure TForm1.escapicua2Click(Sender: TObject);
 var i,n:byte;
     caracteres:string;
begin
     n:=length(cad); caracteres:='';
     for i := 1 to n do begin
      if i mod 2 >0 then begin
       caracteres:= caracteres + cad[i];
       listbox1.Items.Add(caracteres);
      end;
     end;
     edit1.Text:= caracteres;
end;
   function invert(cad:string):string;
    var inv :string;

    begin
       i:=1; inv:='';
        for i := n downto 1  do  begin
       while cad[i] > '' do begin
        inv:=inv + cad[i]
       end;
      end;
       result:=inv;
    end;
procedure TForm1.examepractico2Click(Sender: TObject);
var
  UltimaPal, Invertida: string;
  PosicionUltimaPal, i: Integer;
begin
  PosicionUltimaPal := LastDelimiter(' ', Cad);
  if PosicionUltimaPal > 0 then
    UltimaPal := Copy(Cad, PosicionUltimaPal + 1, Length(Cad) - PosicionUltimaPal)
  else
    UltimaPal := Cad;
  Invertida := '';
  for i := Length(UltimaPal) downto 1 do
    Invertida :=Invertida + UltimaPal[i];
  Edit3.Text :=Invertida;
  ListBox1.Items.Add(Invertida);


end;

procedure TForm1.invertirfisica1Click(Sender: TObject);

var
  temp: Char;
  i, len,n: Integer;
begin
  n:= Length(cad);

  for i := 1 to n div 2 do
  begin
    temp := cad[i];
    cad[i] := cad[n - i + 1];
    cad[n - i + 1] := temp;
  end;
  Edit3.Text := cad;
  ListBox1.Items.Add(cad);
end;

procedure TForm1.pruebas2Click(Sender: TObject);
 var car : char;
begin

edit3.Text:= BoolToStr(esvocal(car));
end;

end.
