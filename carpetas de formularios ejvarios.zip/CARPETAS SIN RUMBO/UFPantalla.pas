unit UFPantalla;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs,UCSoko, Vcl.ImgList, System.ImageList,
  Vcl.StdCtrls,UCCadena;

type
  TForm1 = class(TForm)
    ImageList1: TImageList;
    procedure FormCreate(Sender: TObject);
    procedure FormDblClick(Sender: TObject);
    procedure FormPaint(Sender: TObject);
    procedure FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
  private
    { Private declarations }
    Juego : Terreno;
    l : cadena;
  public
    { Public declarations }
    x,y,m,n :word;
    return:string;
    g : boolean;
  end;

var
  Form1: TForm1;

implementation

{$R *.dfm}

procedure TForm1.FormCreate(Sender: TObject);
begin
     Juego := Terreno.Create;
     l:=cadena.create;
     Juego.CargarEtapa(1);
     x:=juego.getposx(3);
     y:=juego.getposy(3);
     m:=juego.getposx(5);
     n:=juego.getposy(5);
     return:='';
end;

procedure TForm1.FormDblClick(Sender: TObject);
begin
     application.Terminate;
end;

procedure TForm1.FormKeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
var
f,c,a,b : word;
  i: Integer;
begin
   l.addstr(return);
    case key of
    37:begin
        f:=x;
        c:=y-1;
        a:=f;
        b:=c-1;
        if ((juego.getElemento(f,c) = 0) or (juego.getElemento(f,c) = 2)) and not(( (juego.getElemento(a,b) = 1) or (juego.getElemento(a,b) = 2)) and (juego.getElemento(f,c) = 2)) then begin
                  return:='4'+return;
                  juego.mover(x,y,f,c,a,b, return);
                  y:=y-1;
                  form1.Paint;
                  form1.Caption:=return;
        end;
    end;
    38:begin
        f:=x-1;
        c:=y;
        a:=f-1;
        b:=c;
        if ((juego.getElemento(f,c) = 0) or (juego.getElemento(f,c) = 2)) and not(( (juego.getElemento(a,b) = 1) or (juego.getElemento(a,b) = 2)) and (juego.getElemento(f,c) = 2)) then begin
            return:='8'+return;
            juego.mover(x,y,f,c,a,b,return);
            x:=x-1;
            form1.Paint;
            form1.Caption:=return;
        end;
    end;
    39:begin
        f:=x;
        c:=y+1;
        a:=f;
        b:=c+1;
        if ((juego.getElemento(f,c) = 0) or (juego.getElemento(f,c) = 2)) and not(( (juego.getElemento(a,b) = 1) or (juego.getElemento(a,b) = 2)) and (juego.getElemento(f,c) = 2)) then begin
           return:='6'+return;
           juego.mover(x,y,f,c,a,b,return);
           y:=y+1;
           form1.Paint;
           form1.Caption:=return;
        end;
    end;
    40:begin
        f:=x+1;
        c:=y;
        a:=f+1;
        b:=c;
        if ((juego.getElemento(f,c) = 0) or (juego.getElemento(f,c) = 2)) and not (( (juego.getElemento(a,b) = 1) or (juego.getElemento(a,b) = 2))  and (juego.getElemento(f,c) = 2)) then begin
             return:='2'+return;
             juego.mover(x,y,f,c,a,b,return);
             x:=x+1;
             form1.Paint;
             form1.Caption:=return;
        end;
    end;
    82:begin
       case strtoint(return[1]) of
         4:begin
             f:=x;
             c:=y+1;
             a:=f;
             b:=c+1;
             l.delChar(1);
             return:=l.getStr;
             juego.mover(x,y,f,c,a,b,return);
             y:=y+1;
             form1.Paint;
             form1.Caption:=return;
         end;
         6:begin
             f:=x;
             c:=y-1;
             a:=f;
             b:=c-1;
                  l.delChar(1);
                  return:=l.getStr;
                  juego.mover(x,y,f,c,a,b, return);
                  y:=y-1;
                  form1.Paint;
                  form1.Caption:=return;
         end;
         8:begin
             f:=x+1;
             c:=y;
             a:=f+1;
             b:=c;
                l.delChar(1);
                return:=l.getStr;
                juego.mover(x,y,f,c,a,b,return);
                x:=x+1;
                form1.Paint;
                form1.Caption:=return;
         end;
         2:begin
             f:=x-1;
             c:=y;
             a:=f-1;
             b:=c;
                l.delChar(1);
                return:=l.getStr;
                juego.mover(x,y,f,c,a,b,return);
                x:=x-1;
                form1.Paint;
                form1.Caption:=return;
         end;
         7:begin
           case strtoint(return[2]) of
               4:begin
                f:=x;
                c:=y;
                y:=y-1;
                a:=f;
                b:=c+1;
                l.delChar(1);
                l.delChar(1);
                return:=l.getStr;
                juego.inv(x,y,f,c,a,b,return);
                y:=b;
                form1.Paint;
                form1.Caption:=return;
               end;
               6:begin
                f:=x;
                c:=y;
                y:=y+1;
                a:=f;
                b:=c-1;
                l.delChar(1);
                l.delChar(1);
                return:=l.getStr;
                juego.inv(x,y,f,c,a,b, return);
                y:=b;
                form1.Paint;
                form1.Caption:=return;
               end;
               8:begin
                f:=x;
                c:=y;
                x:=x-1;
                a:=f+1;
                b:=c;
                l.delChar(1);
                l.delChar(1);
                return:=l.getStr;
                juego.inv(x,y,f,c,a,b,return);
                x:=a;
                form1.Paint;
                form1.Caption:=return;
               end;
               2:begin
                f:=x;
                c:=y;
                x:=x+1;
                a:=f-1;
                b:=c;
                l.delChar(1);
                l.delChar(1);
                return:=l.getStr;
                juego.inv(x,y,f,c,a,b,return);
                x:=a;
                form1.Paint;
                form1.Caption:=return;
               end;
           end;
         end;
       end;
    end;

    end;

    if (juego.getend) = 0 then begin
            form1.FormCreate(sender);
            form1.Paint;
    end;
end;

procedure TForm1.FormPaint(Sender: TObject);
var
  I,J,X,Y: Integer;
begin
     Y:=0;
     for I := 1 to Juego.Filas do
     Begin
         X:=0;
         for j := 1 to Juego.Columnas do
         Begin
           ImageList1.Draw(Canvas,X,Y,Juego.getElemento(i,j));
           X:=X+32;
         End;
         Y:=Y+32;
     End;
end;

end.
