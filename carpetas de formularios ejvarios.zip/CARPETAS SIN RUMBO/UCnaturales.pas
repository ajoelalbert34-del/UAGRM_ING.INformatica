unit UCnaturales;

interface
 uses SysUtils,Math;
  type
 NumeroNatural=class
   private
   valor:word ;
   public
   constructor create ;
   procedure CambiarValor(V: Word);
   function ObtenerValor:word;
   function ContarDigito:byte;
    function sumarDig:byte;
    function invertirnum:word;
    function promN:Real; /// 1) mostrar el promedio de los numeros naturales  prom= 6 / 3 = 2
    function DGprimo:word;  ///  2) mostrar en otro numero los digitos primos  nprim:= 23
     function DGbin:string; /// 3) mostrar otro numero en digitos binarios  n:=25  mostrar  bin := 11001
      function DGmayor:byte;       ///  4) mostrar el digito mayor de un numero n:=123 . may :=3
     function sumafac:real;
     function octal:string;  ///// tarea 1
     function primeryultimo:integer; ////tarea 2
     function pares:string;    /////tarea 3
     function imparindice:integer;  //// tarea 4
     function ordenarnumero:string;  ////ordenar digito
     function promedioDG:real; ///promedio primer y ultimo digito
     function digitomenor:integer; ///digito menor
     function Digitoprimoconindicepar:integer;  ///digito primo con idice par
     function sumaDGcentro:integer; /// suma de los digitos de centro
     function prompriultmed:real; //// promedio de el primer ,el ultimo y termino medio;
 end;



implementation
constructor NumeroNatural.create;
begin
 Valor:=0;
end;
procedure NumeroNatural.CambiarValor(V: Word);
begin
 Valor:=V;
end;
function NumeroNatural.ObtenerValor:word;
begin
 ObtenerValor:=Valor
end;
function NumeroNatural.ContarDigito:byte;
var n: word;
 c: byte;
begin
 c:=0;
 n:=Valor;
 repeat
 n:=n div 10;
 inc(c); // c:=c+1;
 until n=0;
 result:=c;
end;
 function NumeroNatural.sumarDig;
 var n:word;
     d,sd:byte;
 begin
     sd:=0;
     n:= valor;
     while n>0 do
     begin
      d:=n mod 10;
      sd:=sd+d;
      n:=n mod 10;
     end;

     result:= sd;
 end;
  function NumeroNatural.invertirnum;
   var n,inv:word;
        d:byte;
   begin
    n :=valor; d:=0;
   while n>0 do
    begin
    d:= n mod 10 ;
    inv:=inv*10+d;
    n:=n div 10 ;
    end;
    result:= inv;
     end;
      function NumeroNatural.promN:Real;
      var prom:real;
          sum,num:integer;
          c:byte;
          n:word;
      begin
      n:=valor; c:=0; sum:=0;
       while n>0 do
     begin
      num:=n mod 10;
      sum:=sum+num;
      n:= n div 10;
      c:=c+1;
     end;
     prom:= sum / c;
     result:= prom;
      end;

      function NumeroNatural.DGprimo:word;
       var modi,modi2,n:word;
           num:integer;
       begin
         n:= valor; modi:=0; modi2:=0;
         while n>0 do
         begin
          num:= n mod 10;
          if num in [2,3,5,7] then
           begin
             modi:= modi*10+ num;
           end;
           n:= n div 10 ;
         end;
         while modi>0 do
         begin
           num := modi mod 10;
           modi2:= modi2*10+num;
           modi:= modi div 10;
         end;
         result:= modi2;
       end;


 function NumeroNatural.DGbin: String;
var
  n: Word;
  binario: String;
begin
  n := valor;
  binario := '';

  while n > 0 do
  begin
    binario := IntToStr(n mod 2) + binario;
    n := n div 2;
  end;

  result := binario;
end;

function NumeroNatural.DGmayor:byte;
 var n,num,mayor:word;
begin
 n:=valor; mayor:=0;
  while n>0 do
  begin
  num:= n mod 10;
   if mayor < num then
     begin
       mayor:= num ;
     end;
  n:= n div 10 ;
  end;
  result:=mayor;
end;
  /////modelo examen
 function NumeroNatural.sumafac:real;
  var fibo,f1,f2,c,a:integer;
      acu,fac,fac1,n:word;
     suma:real;
 begin
     n:=valor;
    f1:=-7; f2:=8; fibo:=0; suma:=0; fac:=1; c:=1;  a:=1; fac1:=1;

      while c<=n do
      begin
         fibo:=f1+f2;
         while a<= fac do
          begin
           fac1:=fac1 * a;

            a:=a+1;
          end;
          a:=1;

         suma:= fibo / fac1;
         f1:=f2; f2:=fibo;
         fac:=fac+2;
         c:=c+1;
      end;
       result:= suma;


 end;


  function NumeroNatural.octal:string;
  var num,inver:integer;
  octal:string;
   n:word;
begin
    n:=valor;
   octal:=''; inver:=0;
    while n>0 do
   begin
   octal:= IntToStr( n mod 8)+ octal;
   n:= n div 8 ;
   end;


   result:= octal;

end;

  function NumeroNatural.primeryultimo:integer;
      var acu,num,final,l:integer;
          n:word;
 begin
    n:=valor;
   acu:=0; final:=0;

   l:=  Trunc(Log10(n) + 1);  // length(IntToStr(n));
   if l=2 then
    begin
      final:= 0;

    end else begin
   if l >=3 then
    begin
    n:= n div 10;
    while n>0 do
    begin
     num:= n mod 10 ;
     acu:= acu * 10 + num;
     n:= n div 10;
    end;
    acu:= acu div 10;
    while acu>0 do
    begin
      num:= acu mod 10;
      final:= final * 10 + num;
      acu:=acu div 10;

    end;
    end;
    end;
     result:= (final);
end;
     function NumeroNatural.pares:string;
      var num,x:integer;
          pares:string;
      n:word;
begin
 n:=valor; x :=0;
 pares :='';
  while n>0 do
  begin
    num:= n mod 10 ;
     if num mod 2 = 0 then
      begin
       pares:= IntToStr(num)+pares;
      end;
      n:=n div 10 ;

  end;
     result:=pares;

     end;

     function NumeroNatural.imparindice:integer;
    var c,num,indice:integer;
        n:word;
begin
 c:=1;indice:=0; n:=valor;
     while n>0 do
     begin
      num:= n mod 10;
      if c mod 2>0 then
      begin
       indice:= indice * 10 + (n mod 10);
      end;
      c:=c+1;
      n:= n div 10 ;

     end;
     result:=indice;
end;
 function NumeroNatural.ordenarnumero:string;
var
  nStr, ordenado, nuevoStr: string;
  menor: Char;
  i: Integer;
  n:word;
  encontrado: Boolean;
begin
   n:=valor;
  nStr := IntToStr(n);
  ordenado := '';
  while Length(nStr) > 0 do
  begin

    menor := '9';
    for i := 1 to Length(nStr) do
    begin
      if nStr[i] < menor then
        menor := nStr[i];
    end;
    ordenado := ordenado + menor;
    encontrado := False;
    nuevoStr := '';

    for i := 1 to Length(nStr) do
    begin
      if (nStr[i] = menor) and not (encontrado) then
      begin
        encontrado := True;
      end
      else
      begin

        nuevoStr := nuevoStr + nStr[i];
      end;
    end;
    nStr := nuevoStr;
  end;
  result := ordenado;
end;

function NumeroNatural.promedioDG:real;
var sd,num,inve,c:integer;
    prom:real;
    n:word;
begin
  n:=valor;
c:=1; inve:=0;  prom:=0;   sd:=0;
    if c=1 then
     begin
       num:= n mod 10;
       sd:= sd+num;
       c:=c+1;
     end;
     num:=0;
     while n>0 do
     begin
       num:= n mod 10;
       inve:=inve*10 + num ;
       n:=n div 10;
     end;
     num:=0;
     num:= inve mod 10;
     sd:= sd + num;
      prom:= sd / c;
      result:= (prom);
end;
 function NumeroNatural.digitomenor:integer;
 var num,menor:integer;
  n:word;
begin
 n:=valor;
   menor:=9;
   while n>0 do
   begin
     num:= n mod 10;
      if menor>num then
       begin
         menor:=num;
       end;
       n:= n div 10;
   end;
    result:= (menor);
end;
 function NumeroNatural.Digitoprimoconindicepar:integer;
 var  primo,indice,num:integer;
      n:word;
begin
 n:=valor;
indice:=0;
primo:=0;
   while n>0 do
    begin
     indice:=indice+1;
     num:= n mod 10;
  if ((num) in [2,3,5,7]) AND (indice mod 2 = 0 )then
      begin
       primo:= primo*10+ num;
      end;
      n := n div 10;
    end;
    result:=(primo);
end;
 function NumeroNatural.sumaDGcentro:integer;
 var lon,num,sd,c1,c2,i:integer;
      n:word;
begin
  n:=valor; sd:=0;
  lon:=trunc(log10(n)+1); i:=0;
  if lon mod 2 = 0 then
  begin
   c1:= lon div 2;
   c2:= c1+1;
   while n >0 do
   begin
     num:=n mod 10;
     i:=i+1;
     if (i=c1) OR (i=c2) then
     begin
       sd:= sd+num;
     end;
     n:= n div 10;
   end;
  end ;
  result:= sd ;
end;
function NumeroNatural.prompriultmed:real;
var num,nult,npri, inv,lon,x:integer;
sumaprom:real;
nSTR:string;
n:word;
begin
 n:=valor;
inv:=0; nult:=0; lon:=0; sumaprom:=0;
    nult:= n mod 10;
    while n>0 do
    begin
     num:= n mod 10;
     inv:= inv*10 + num;
     n:= n div 10;
    end;
    npri:= inv mod 10;
    nSTR:= IntToStr(inv);
    lon:= length(nSTR);
    if lon mod 2 >0  then
    begin
     x:=( lon+1) div 2;
    end;
    sumaprom:=( sumaprom + nult+npri + StrToInt(nSTr[x]))/3;
    result:= (sumaprom) ;
end;

end.

