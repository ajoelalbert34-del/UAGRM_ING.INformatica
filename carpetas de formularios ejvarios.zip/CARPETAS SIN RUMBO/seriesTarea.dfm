object Form1: TForm1
  Left = 0
  Top = 0
  Caption = 'seriesvarias'
  ClientHeight = 552
  ClientWidth = 795
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -16
  Font.Name = 'Segoe UI'
  Font.Style = [fsBold]
  Menu = MainMenu1
  TextHeight = 21
  object Label1: TLabel
    Left = 64
    Top = 80
    Width = 59
    Height = 21
    Caption = 'entrada'
  end
  object Label2: TLabel
    Left = 64
    Top = 152
    Width = 45
    Height = 21
    Caption = 'salida'
  end
  object Label3: TLabel
    Left = 536
    Top = 96
    Width = 59
    Height = 21
    Caption = 'mostrar'
  end
  object Edit1: TEdit
    Left = 168
    Top = 77
    Width = 193
    Height = 29
    TabOrder = 0
    Text = 'ingrese un numero'
  end
  object Edit2: TEdit
    Left = 168
    Top = 149
    Width = 193
    Height = 29
    TabOrder = 1
    Text = 'ingrese un numero'
  end
  object ListBox1: TListBox
    Left = 456
    Top = 149
    Width = 281
    Height = 316
    ItemHeight = 21
    TabOrder = 2
  end
  object Button1: TButton
    Left = 56
    Top = 360
    Width = 185
    Height = 25
    Caption = 'limpiar'
    TabOrder = 3
    OnClick = Button1Click
  end
  object BitBtn1: TBitBtn
    Left = 272
    Top = 360
    Width = 129
    Height = 33
    Kind = bkClose
    NumGlyphs = 2
    TabOrder = 4
  end
  object MainMenu1: TMainMenu
    Left = 720
    Top = 8
    object series1: TMenuItem
      Caption = 'series'
      object parimpar1: TMenuItem
        Caption = 'parimpar'
        OnClick = parimpar1Click
      end
      object doblecuadrado1: TMenuItem
        Caption = 'doblecuadrado'
        OnClick = doblecuadrado1Click
      end
      object fibonaccidoble1: TMenuItem
        Caption = 'fibonaccidoble'
        OnClick = fibonaccidoble1Click
      end
      object cuadradomultiplode31: TMenuItem
        Caption = 'cuadradomultiplode3'
        OnClick = cuadradomultiplode31Click
      end
      object dobledefibo1: TMenuItem
        Caption = 'dobledefibo'
        OnClick = dobledefibo1Click
      end
    end
    object series2: TMenuItem
      Caption = 'switcht'
    end
    object practico41: TMenuItem
      Caption = 'practico#4'
      object see1: TMenuItem
        Caption = 'serie1'
        OnClick = see1Click
      end
      object serie21: TMenuItem
        Caption = 'serie2'
      end
    end
    object tareamiercoles1: TMenuItem
      Caption = 'tareamiercoles'
      object serieuno1: TMenuItem
        Caption = 'serieuno'
        OnClick = serieuno1Click
      end
      object seriedos1: TMenuItem
        Caption = 'seriedos'
        OnClick = seriedos1Click
      end
      object serietres1: TMenuItem
        Caption = 'serietres'
        OnClick = serietres1Click
      end
      object seriecuatro1: TMenuItem
        Caption = 'seriecuatro'
        OnClick = seriecuatro1Click
      end
    end
  end
end
