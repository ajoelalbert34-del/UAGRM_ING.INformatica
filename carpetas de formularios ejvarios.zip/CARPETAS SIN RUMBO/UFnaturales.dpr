program UFnaturales;

uses
  Vcl.Forms,
  UCNumero in 'UCNumero.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
 // Application.CreateForm(TForm1, Form1);
  Application.Run;
end.
