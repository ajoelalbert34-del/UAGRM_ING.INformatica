object Form1: TForm1
  Left = 0
  Top = 0
  Caption = 'Form1'
  ClientHeight = 515
  ClientWidth = 810
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = 'Segoe UI'
  Font.Style = []
  Menu = MainMenu1
  PixelsPerInch = 96
  TextHeight = 15
  object crear: TLabel
    Left = 64
    Top = 123
    Width = 26
    Height = 15
    Caption = 'crear'
    OnClick = crearClick
  end
  object CambiarValordeN: TLabel
    Left = 64
    Top = 179
    Width = 93
    Height = 15
    Caption = 'CambiarValordeN'
    OnClick = CambiarValordeNClick
  end
  object Edit1: TEdit
    Left = 200
    Top = 120
    Width = 369
    Height = 23
    TabOrder = 0
    Text = 'Edit1'
  end
  object Edit2: TEdit
    Left = 200
    Top = 176
    Width = 393
    Height = 23
    TabOrder = 1
    Text = 'Edit2'
  end
  object Button1: TButton
    Left = 368
    Top = 248
    Width = 75
    Height = 25
    Caption = 'mostrar'
    TabOrder = 2
    OnClick = Button1Click
  end
  object BitBtn1: TBitBtn
    Left = 120
    Top = 248
    Width = 75
    Height = 25
    Kind = bkClose
    NumGlyphs = 2
    TabOrder = 3
  end
  object Button2: TButton
    Left = 232
    Top = 344
    Width = 75
    Height = 25
    Caption = 'Button2'
    TabOrder = 4
    OnClick = Button2Click
  end
  object MainMenu1: TMainMenu
    Left = 664
    Top = 8
    object mostrarPOO1: TMenuItem
      Caption = 'mostrarPOO'
      object contarDg1: TMenuItem
        Caption = 'contarDg'
        OnClick = contarDg1Click
      end
      object ccmabiarvalorDG1: TMenuItem
        Caption = 'cambiarvalorDG'
        OnClick = ccmabiarvalorDG1Click
      end
      object obtener1: TMenuItem
        Caption = 'obtenervalorDG'
      end
    end
    object clasePOO1: TMenuItem
      Caption = 'clasePOO'
      OnClick = clasePOO1Click
      object promeN1: TMenuItem
        Caption = 'promeN'
        OnClick = promeN1Click
      end
      object dgPRIMO1: TMenuItem
        Caption = 'dgPRIMO'
        OnClick = dgPRIMO1Click
      end
      object binario1: TMenuItem
        Caption = 'binario'
        OnClick = binario1Click
      end
      object binario2: TMenuItem
        Caption = 'DGmayor'
        OnClick = binario2Click
      end
    end
    object modeloexamen1: TMenuItem
      Caption = 'modeloexamen'
      object modeloexamen2: TMenuItem
        Caption = 'mod1'
        OnClick = modeloexamen2Click
      end
      object mod21: TMenuItem
        Caption = 'mod2'
      end
      object mod31: TMenuItem
        Caption = 'mod3'
        OnClick = mod31Click
      end
    end
    object tareaPOO1: TMenuItem
      Caption = 'tareaPOO'
      object tareaPOO2: TMenuItem
        Caption = 'tarea1'
        OnClick = tareaPOO2Click
      end
      object tarea21: TMenuItem
        Caption = 'tarea2'
        OnClick = tarea21Click
      end
      object tarea31: TMenuItem
        Caption = 'tarea3'
        OnClick = tarea31Click
      end
      object tarea41: TMenuItem
        Caption = 'tarea4'
        OnClick = tarea41Click
      end
      object ordenarnumero1: TMenuItem
        Caption = 'ordenarnumero'
        OnClick = ordenarnumero1Click
      end
      object promedioprimeryultimodigito1: TMenuItem
        Caption = 'promedioprimeryultimodigito'
        OnClick = promedioprimeryultimodigito1Click
      end
      object numeromenor1: TMenuItem
        Caption = 'numeromenor'
        OnClick = numeromenor1Click
      end
      object digitoprimoconindicepar1: TMenuItem
        Caption = 'digitoprimoconindicepar'
        OnClick = digitoprimoconindicepar1Click
      end
      object sumadelosdigitosdelcentro1: TMenuItem
        Caption = 'sumadelosdigitosdelcentro'
        OnClick = sumadelosdigitosdelcentro1Click
      end
      object promPRiultMED1: TMenuItem
        Caption = 'promPRiultMED'
        OnClick = promPRiultMED1Click
      end
    end
    object ordenar1: TMenuItem
      Caption = 'ordenar'
      object ordenar2: TMenuItem
        Caption = 'ordenar+'
        OnClick = ordenar2Click
      end
    end
    object ExamenFInal1: TMenuItem
      Caption = 'ExamenFInal'
      object ejercicioFianl11: TMenuItem
        Caption = 'ejercicioFianl1'
      end
      object ejercicioFianl12: TMenuItem
        Caption = 'ejercicioFinal2'
      end
      object ejerciciofinal31: TMenuItem
        Caption = 'ejerciciofinal3'
      end
      object ejerciciofinal32: TMenuItem
        Caption = 'ejerciciofinal3'
      end
    end
  end
end
