object Form1: TForm1
  Left = 0
  Top = 0
  Caption = 'seriesvarias'
  ClientHeight = 552
  ClientWidth = 795
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -16
  Font.Name = 'Segoe UI'
  Font.Style = [fsBold]
  Menu = MainMenu1
  PixelsPerInch = 96
  TextHeight = 21
  object Label1: TLabel
    Left = 64
    Top = 80
    Width = 59
    Height = 21
    Caption = 'entrada'
  end
  object Label2: TLabel
    Left = 64
    Top = 152
    Width = 45
    Height = 21
    Caption = 'salida'
  end
  object Label3: TLabel
    Left = 536
    Top = 96
    Width = 59
    Height = 21
    Caption = 'mostrar'
  end
  object Edit1: TEdit
    Left = 168
    Top = 77
    Width = 193
    Height = 29
    TabOrder = 0
    Text = 'ingrese un numero'
  end
  object Edit2: TEdit
    Left = 168
    Top = 149
    Width = 193
    Height = 29
    TabOrder = 1
    Text = 'ingrese un numero'
  end
  object ListBox1: TListBox
    Left = 456
    Top = 149
    Width = 281
    Height = 316
    ItemHeight = 21
    TabOrder = 2
  end
  object Button1: TButton
    Left = 56
    Top = 360
    Width = 185
    Height = 25
    Caption = 'limpiar'
    TabOrder = 3
    OnClick = Button1Click
  end
  object BitBtn1: TBitBtn
    Left = 272
    Top = 360
    Width = 129
    Height = 33
    Kind = bkClose
    NumGlyphs = 2
    TabOrder = 4
  end
  object MainMenu1: TMainMenu
    Left = 720
    Top = 8
    object series1: TMenuItem
      Caption = 'series'
      object parimpar1: TMenuItem
        Caption = 'parimpar'
        OnClick = parimpar1Click
      end
      object doblecuadrado1: TMenuItem
        Caption = 'doblecuadrado'
        OnClick = doblecuadrado1Click
      end
      object fibonaccidoble1: TMenuItem
        Caption = 'fibonaccidoble'
        OnClick = fibonaccidoble1Click
      end
      object cuadradomultiplode31: TMenuItem
        Caption = 'cuadradomultiplode3'
        OnClick = cuadradomultiplode31Click
      end
      object dobledefibo1: TMenuItem
        Caption = 'dobledefibo'
        OnClick = dobledefibo1Click
      end
    end
    object series2: TMenuItem
      Caption = 'switcht'
    end
    object practico41: TMenuItem
      Caption = 'practico#4'
      object see1: TMenuItem
        Caption = 'serie1'
        OnClick = see1Click
      end
      object serie21: TMenuItem
        Caption = 'serie2'
      end
    end
    object tareamiercoles1: TMenuItem
      Caption = 'tareamiercoles'
      object serieuno1: TMenuItem
        Caption = 'serieuno'
        OnClick = serieuno1Click
      end
      object seriedos1: TMenuItem
        Caption = 'seriedos'
        OnClick = seriedos1Click
      end
      object serietres1: TMenuItem
        Caption = 'serietres'
        OnClick = serietres1Click
      end
      object seriecuatro1: TMenuItem
        Caption = 'seriecuatro'
        OnClick = seriecuatro1Click
      end
    end
    object miercoles181: TMenuItem
      Caption = 'miercoles18'
      object sumarfibonaccifactorial1: TMenuItem
        Caption = 'sumarfibonaccifactorial'
        OnClick = sumarfibonaccifactorial1Click
      end
      object sdoblefactorialfibonacci1: TMenuItem
        Caption = 'sdoblefactorialfibonacci'
      end
      object sdoblefactorialfibonacci2: TMenuItem
        Caption = 'sdoblefactorialfibonacci'
      end
    end
    object tareaviernes271: TMenuItem
      Caption = 'tareaviernes27'
      object contardigitos1: TMenuItem
        Caption = 'contardigitos'
        OnClick = contardigitos1Click
      end
      object sumardigitos1: TMenuItem
        Caption = 'sumardigitos'
        OnClick = sumardigitos1Click
      end
      object promedio1: TMenuItem
        Caption = 'promedio'
        OnClick = promedio1Click
      end
      object promedio2: TMenuItem
        Caption = 'mayordigito'
        OnClick = promedio2Click
      end
      object invertir1: TMenuItem
        Caption = 'invertir'
        OnClick = invertir1Click
      end
      object contarParImpar1: TMenuItem
        Caption = 'contarParImpar'
        OnClick = contarParImpar1Click
      end
      object sumarPar1: TMenuItem
        Caption = 'sumarPar'
        OnClick = sumarPar1Click
      end
      object siEsCapicua2: TMenuItem
        Caption = 'siEsCapicua'
        OnClick = siEsCapicua2Click
      end
    end
    object natural271: TMenuItem
      Caption = 'natural indice'
      object sumarIndiceImpar1: TMenuItem
        Caption = 'sumarIndiceImpar'
        OnClick = sumarIndiceImpar1Click
      end
      object SPrimeroyUltimo1: TMenuItem
        Caption = 'S_PrimeroyUltimo'
        OnClick = SPrimeroyUltimo1Click
      end
      object promedioIndicepar1: TMenuItem
        Caption = 'promedioIndicepar'
        OnClick = promedioIndicepar1Click
      end
      object promedioIndicepar2: TMenuItem
        Caption = 'mayorIndicePar'
        OnClick = promedioIndicepar2Click
      end
    end
    object su1: TMenuItem
      Caption = 'sumaSerie'
    end
    object funciones1: TMenuItem
      Caption = 'funciones '
      object funciones2: TMenuItem
        Caption = 'promediodelParImapar'
      end
      object promediodeFibonacciCuadrado1: TMenuItem
        Caption = 'promediodeFibonacciCuadrado'
      end
    end
    object funcionesNaturales1: TMenuItem
      Caption = 'funcionesNaturales'
      object funcion11: TMenuItem
        Caption = 'funcion1'
      end
      object funcion21: TMenuItem
        Caption = 'funcion2'
      end
      object funcion31: TMenuItem
        Caption = 'funcion3'
      end
      object funcion41: TMenuItem
        Caption = 'funcion4'
      end
      object fu1: TMenuItem
        Caption = 'fu'
      end
    end
  end
end
