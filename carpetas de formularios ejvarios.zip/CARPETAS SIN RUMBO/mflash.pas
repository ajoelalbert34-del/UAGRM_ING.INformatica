unit mflash;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.Buttons, Vcl.StdCtrls, Vcl.Menus;

type
  TForm1 = class(TForm)
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Edit1: TEdit;
    Edit2: TEdit;
    ListBox1: TListBox;
    Button1: TButton;
    BitBtn1: TBitBtn;
    MainMenu1: TMainMenu;
    series1: TMenuItem;
    series2: TMenuItem;
    parimpar1: TMenuItem;
    doblecuadrado1: TMenuItem;
    fibonaccidoble1: TMenuItem;
    cuadradomultiplode31: TMenuItem;
    dobledefibo1: TMenuItem;
    practico41: TMenuItem;
    see1: TMenuItem;
    serie21: TMenuItem;
    tareamiercoles1: TMenuItem;
    serieuno1: TMenuItem;
    seriedos1: TMenuItem;
    serietres1: TMenuItem;
    seriecuatro1: TMenuItem;
    miercoles181: TMenuItem;
    sumarfibonaccifactorial1: TMenuItem;
    sdoblefactorialfibonacci1: TMenuItem;
    sdoblefactorialfibonacci2: TMenuItem;
    tareaviernes271: TMenuItem;
    contardigitos1: TMenuItem;
    sumardigitos1: TMenuItem;
    promedio1: TMenuItem;
    promedio2: TMenuItem;
    invertir1: TMenuItem;
    contarParImpar1: TMenuItem;
    sumarPar1: TMenuItem;
    siEsCapicua2: TMenuItem;
    natural271: TMenuItem;
    sumarIndiceImpar1: TMenuItem;
    SPrimeroyUltimo1: TMenuItem;
    promedioIndicepar1: TMenuItem;
    promedioIndicepar2: TMenuItem;
    su1: TMenuItem;
    funciones1: TMenuItem;
    funciones2: TMenuItem;
    promediodeFibonacciCuadrado1: TMenuItem;
    funcionesNaturales1: TMenuItem;
    funcion11: TMenuItem;
    funcion21: TMenuItem;
    funcion31: TMenuItem;
    funcion41: TMenuItem;
    fu1: TMenuItem;
    procedure parimpar1Click(Sender: TObject);
    procedure doblecuadrado1Click(Sender: TObject);
    procedure fibonaccidoble1Click(Sender: TObject);
    procedure cuadradomultiplode31Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure dobledefibo1Click(Sender: TObject);
    procedure see1Click(Sender: TObject);
    procedure serieuno1Click(Sender: TObject);
    procedure seriedos1Click(Sender: TObject);
    procedure serietres1Click(Sender: TObject);
    procedure seriecuatro1Click(Sender: TObject);
    procedure sumarfibonaccifactorial1Click(Sender: TObject);
    procedure contardigitos1Click(Sender: TObject);
    procedure sumardigitos1Click(Sender: TObject);
    procedure promedio1Click(Sender: TObject);
    procedure promedio2Click(Sender: TObject);
    procedure invertir1Click(Sender: TObject);
    procedure contarParImpar1Click(Sender: TObject);
    procedure sumarPar1Click(Sender: TObject);
    procedure siEsCapicua2Click(Sender: TObject);
    procedure sumarIndiceImpar1Click(Sender: TObject);
    procedure promedioIndicepar1Click(Sender: TObject);
    procedure SPrimeroyUltimo1Click(Sender: TObject);
    procedure promedioIndicepar2Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form1: TForm1;

implementation

{$R *.dfm}

procedure TForm1.Button1Click(Sender: TObject);
begin
   edit1.clear;
   edit2.clear;
   listbox1.clear;
   edit1.setFocus;
end;

procedure TForm1.contardigitos1Click(Sender: TObject);

var
  n, contador: Integer;
begin
  n := StrToInt(Edit1.Text);
  contador := 0;

  while n > 0 do
  begin
    n := n div 10;
    contador := contador + 1;
  end;

  ListBox1.Items.Add('Cantidad de d�gitos: ' + IntToStr(contador));


end;

procedure TForm1.contarParImpar1Click(Sender: TObject);

var
  n, par, impar, digito: Integer;
begin
  n := StrToInt(Edit1.Text);
  par := 0;
  impar := 0;

  while n > 0 do
  begin
    digito := n mod 10;
    if digito mod 2 = 0 then
      par := par + 1
    else
      impar := impar + 1;
    n := n div 10;
  end;

  ListBox1.Items.Add('D�gitos pares: ' + IntToStr(par));
  ListBox1.Items.Add('D�gitos impares: ' + IntToStr(impar));

end;

procedure TForm1.cuadradomultiplode31Click(Sender: TObject);
   var n,i,c,mul:integer;
begin
     n:=StrToInt(edit1.text); c:=0; i:=1; mul:=0;
       while c <= n do
       begin
         mul:= i*i;
           if mul mod 3 = 0 then
           begin
             listbox1.Items.Add(IntToStr(mul));
           end;
           i:=i+1;
           c:=c+1;
       end;

end;

procedure TForm1.doblecuadrado1Click(Sender: TObject);
 var n,d,q,iq,c : integer;
     sw:boolean;
begin
     d:=1; q:=1; iq:=3; sw:= true; n:= StrToInt(edit1.text);
       for c := 1 to n do
        begin
          if sw = true then
             begin
               listbox1.Items.Add(IntToStr(d));
                d:= d*2;
                sw:= false;

             end
             else
             begin
               listbox1.Items.Add(IntToStr(q));
               q:=q+iq;
               iq:=IQ+2;
               sw:= true;
             end;
        end;

end;

procedure TForm1.dobledefibo1Click(Sender: TObject);
  var n,c,fibo,f1,f2:integer;

begin
     n:= StrToInt(edit1.text); c:=0; fibo:=0; f1:=1; f2:=0;
       while c<= n do
       begin
         fibo:= f1+2*f2;
           listbox1.Items.Add(IntToStr(fibo));
           f1:=f2;
           f1:=fibo;
           c:=c+1;
       end;

end;

procedure TForm1.fibonaccidoble1Click(Sender: TObject);
 var n,c,fibo,f1,f2,fibona,fa,fb : integer;
     sw:boolean;
 begin
        n:=StrToInt(edit1.text); c:= 1; fibo:=0; f1:=1; f2:=0; fibona:=0; fa:=1; fb:=0;

       while c<=n do begin

          if sw = true then  begin

               fibo:=f1+f2;
               listbox1.Items.Add(IntToStr(fibo));
               f1:=f2;
               f2:=fibo;
               sw:= false;
           end else begin

               fibona:=fa+fb;
               listbox1.Items.Add(IntToStr(fibona));
               fa:=fb;
               fb:= fibona;
               sw:=true;
             end;
             c:= c +1;
       end;

 end;

procedure TForm1.invertir1Click(Sender: TObject);

var
  n, invertido: Integer;
begin
  n := StrToInt(Edit1.Text);
  invertido := 0;

  while n > 0 do
  begin
    invertido := (invertido * 10) + (n mod 10);
    n := n div 10;
  end;

  ListBox1.Items.Add('N�mero invertido: ' + IntToStr(invertido));

end;

procedure TForm1.parimpar1Click(Sender: TObject);
 var num : integer ;

begin
   num:=StrToInt(edit1.text);
    if num mod 2 = 0 then begin
       listbox1.Items.Add('el numero es par');
      end else begin
        listbox1.Items.Add('el numero es impar');
    end;
end;
procedure TForm1.promedio1Click(Sender: TObject);

var
  n, suma, contador: Integer;
  promedio: Real;
begin
  n := StrToInt(Edit1.Text);
  suma := 0;
  contador := 0;

  while n > 0 do
  begin
    suma := suma + (n mod 10);
    n := n div 10;
    contador := contador + 1;
  end;

  if contador > 0 then
    promedio := suma / contador
  else
    promedio := 0;

  ListBox1.Items.Add('Promedio de los d�gitos: ' + FloatToStr(promedio));

end;

procedure TForm1.promedio2Click(Sender: TObject);

var
  n, mayor, digito: Integer;
begin
  n := StrToInt(Edit1.Text);
  mayor := 0;

  while n > 0 do
  begin
    digito := n mod 10;
    if digito > mayor then
      mayor := digito;
    n := n div 10;
  end;

  ListBox1.Items.Add('Mayor d�gito: ' + IntToStr(mayor));

end;

procedure TForm1.promedioIndicepar1Click(Sender: TObject);
var
  n, digito, suma, contador, indice, numeroTemporal: Integer;
  promedio: Real;
begin
  n := StrToInt(Edit1.Text);
  suma := 0;
  contador := 0;
  indice := 1;
  numeroTemporal := n; // Almacenamos el n�mero original en una variable temporal

  while numeroTemporal > 0 do
  begin
    digito := numeroTemporal mod 10;

    if indice mod 2 = 0 then
    begin
      suma := suma + digito;
      contador := contador + 1;
    end;

    numeroTemporal := numeroTemporal div 10;
    indice := indice + 1;
  end;

  if contador > 0 then
    promedio := suma / contador
  else
    promedio := 0;

  ListBox1.Items.Add(  FloatToStr(promedio));


end;

procedure TForm1.promedioIndicepar2Click(Sender: TObject);
var
  n, digito, suma, contador, indice: Integer;
  promedio: Real;
begin
  n := StrToInt(Edit1.Text);
  contador := 0;
  indice := 1;


  while n > 0 do
  begin
    digito := n mod 10;


    if indice mod 2 = 0 then
    begin
      suma := suma + digito;
      contador := contador + 1;
    end;

    n := n div 10;
    indice := indice + 1;
  end;


  if contador > 0 then
    promedio := suma / contador
  else
    promedio := 0;
  ListBox1.Items.Add(FloatToStr(promedio));

end;

procedure TForm1.see1Click(Sender: TObject);
var n,c,a,ia,b,ib : integer;
     sw : boolean;

begin
     n:=StrToInt(edit1.text); c:=1; a:=31; b:=41; ia:=28; ib:=12; sw:= true;
      for c := 1 to n do
      begin
           if sw=true then
           begin
             listbox1.Items.Add(IntToStr(a));
             a:=a+ia;
             ia:=ia+2;
             sw:=false;
           end else begin
             listbox1.Items.Add(IntToStr(b));
             b:=b+ib;
             ib:=(ib*2)+2;
             sw:= true;
           end;

      end;

end;

procedure TForm1.seriecuatro1Click(Sender: TObject);
var
  n, c, fibo, f1, f2, fac, sum: Integer;
  sw: Boolean;
begin
  n := StrToInt(edit1.text);
  fibo := 0;
  f1 := 1;
  f2 := 1;
  fac := 1;
  sum := 0;
  sw := True;
  for c := 1 to n do
  begin
    if sw then
    begin
      if c = 1 then
      begin
        fibo := f1;
      end
      else
      begin
        fibo := f1 + f2;
        f1 := f2;
        f2 := fibo;
      end;

      sum := sum + fibo;
      sw := False;
    end
    else
    begin
      fac := fac * c;
      sum := sum + fac;
      sw := True;
    end;
  end;


  listbox1.Items.Add('La suma de la serie es: ' + IntToStr(sum));
end;

procedure TForm1.seriedos1Click(Sender: TObject);
var
  n, a, b, c, fac, sum, ia: real;
begin
  n := StrToFloat(edit1.text);
  a := 1;
  ia := 1;
  fac := 1;
  c := 1;
  sum := 0;

  while c <= n do
  begin
    fac := fac * c;
    sum := sum + ((a * ia) / fac);
    ia := ia + 1;
    c := c + 1;
  end;

  listbox1.Items.Add('La sumatoria de la serie es:');
  listbox1.Items.Add(FloatToStr(sum));
end;

procedure TForm1.serietres1Click(Sender: TObject);
var
  n, i, c, sum, a: Integer;
begin

  n := StrToInt(edit1.text);
  sum := 0;
  for i := 1 to n do
  begin
    a := 1;
    for c := 1 to i do
    begin
      a := a * i;
    end;
    sum := sum + a;
  end;
  listbox1.Items.Add('la sumatoria es :'+  IntToStr(sum));

end;


procedure TForm1.serieuno1Click(Sender: TObject);

var
  n, sum, c: Integer;

begin

  showmessage('Ingrese el valor de n (m�ximo 12): ');
  n:=StrToInt(edit1.text);
  if n > 12 then
  begin
    n := 12;
  end;
  sum := 0;
  c := 1;
  while c <= n do
  begin
    if c = 1 then
      sum := sum + 1;
    if c = 2 then
      sum := sum + 2;
    if c = 3 then
      sum := sum + 3;
    if c = 4 then
      sum := sum + 3;
    if c = 5 then
      sum := sum + 2;
    if c = 6 then
      sum := sum + 1;
    if c = 7 then
      sum := sum + 1;
    if c = 8 then
      sum := sum + 2;
    if c = 9 then
      sum := sum + 2;
    if c = 10 then
      sum := sum + 1;
    if c = 11 then
      sum := sum + 1;
    if c = 12 then
      sum := sum + 1;
    c := c + 1;
  end;
  listbox1.Items.Add('el resultado de la sumatoria es:');
 listbox1.Items.Add(IntToStr( sum));
end;
procedure TForm1.siEsCapicua2Click(Sender: TObject);

var
  n, invertido, original: Integer;
begin
  n := StrToInt(Edit1.Text);
  original := n;
  invertido := 0;

  while n > 0 do
  begin
    invertido := (invertido * 10) + (n mod 10);
    n := n div 10;
  end;

  if original = invertido then
    ListBox1.Items.Add('Es capic�a')
  else
    ListBox1.Items.Add('No es capic�a');
end;


procedure TForm1.SPrimeroyUltimo1Click(Sender: TObject);
var
  n, primerDigito, ultimoDigito: Integer;
begin
  n := StrToInt(Edit1.Text);
  ultimoDigito := n mod 10;

  while n >= 10 do
  begin
    n := n div 10;
  end;
  primerDigito := n;

  ListBox1.Items.Add( IntToStr(primerDigito + ultimoDigito));

end;

procedure TForm1.sumardigitos1Click(Sender: TObject);

var
  n, suma: Integer;
begin
  n := StrToInt(Edit1.Text);
  suma := 0;

  while n > 0 do
  begin
    suma := suma + (n mod 10);
    n := n div 10;
  end;

  ListBox1.Items.Add('Suma de los d�gitos: ' + IntToStr(suma));

end;

procedure TForm1.sumarfibonaccifactorial1Click(Sender: TObject);
var n,c,fibo,f1,f2,sum,fac :integer;
     sw:boolean;
begin
     n:=StrToInt(edit1.text);fibo:=0; f1:=1; f2:=1;  fac:=-1; c:=2; sw:=true;
end;


procedure TForm1.sumarIndiceImpar1Click(Sender: TObject);
var sdii,d,i:byte;
    n:word;
begin
 n:=StrToInt(edit1.text); sdii:=0; i:=1;
   while n>0 do
   begin
     d:=n mod 10;
     if i mod 2 =1 then
     sdii:=sdii+d;
     i:=i+1;
     n:=n div 10;
   end;
   listbox1.Items.Add(IntToStr(sdii))
end;

procedure TForm1.sumarPar1Click(Sender: TObject);

var
  n, suma, digito: Integer;
begin
  n := StrToInt(Edit1.Text);
  suma := 0;

  while n > 0 do
  begin
    digito := n mod 10;
    if digito mod 2 = 0 then
      suma := suma + digito;
    n := n div 10;
  end;

  ListBox1.Items.Add('Suma de d�gitos pares: ' + IntToStr(suma));
end;


end.
