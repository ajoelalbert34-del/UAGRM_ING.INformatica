program practicasdecodigocadynum;

uses
  Vcl.Forms,
  practicasdecodigo in 'practicasdecodigo.pas' {Form1},
  UCnaturales in 'UCnaturales.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TForm1, Form1);
  Application.Run;
end.
