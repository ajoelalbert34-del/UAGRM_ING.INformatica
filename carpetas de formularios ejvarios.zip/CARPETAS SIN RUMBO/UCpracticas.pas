unit UCpracticas;

interface
 uses SysUtils ;
 type
   cadenas = class
 private
    cad:string;
 public
  constructor create ;

   end;


implementation

  constructor cadenas.create  ;
  begin
   cad:= '';



   end;
end.
