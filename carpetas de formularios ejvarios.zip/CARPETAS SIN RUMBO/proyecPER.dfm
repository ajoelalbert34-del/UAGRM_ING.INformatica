object Form1: TForm1
  Left = 0
  Top = 0
  Caption = 'Form1'
  ClientHeight = 441
  ClientWidth = 624
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = 'Segoe UI'
  Font.Style = []
  Menu = MainMenu1
  PixelsPerInch = 96
  TextHeight = 15
  object entrada: TLabel
    Left = 96
    Top = 83
    Width = 40
    Height = 15
    Caption = 'entrada'
  end
  object salida: TLabel
    Left = 96
    Top = 147
    Width = 30
    Height = 15
    Caption = 'salida'
  end
  object Edit1: TEdit
    Left = 168
    Top = 80
    Width = 297
    Height = 23
    TabOrder = 0
    Text = 'Edit1'
  end
  object Edit2: TEdit
    Left = 168
    Top = 144
    Width = 297
    Height = 23
    TabOrder = 1
    Text = 'Edit2'
  end
  object Button2: TButton
    Left = 88
    Top = 256
    Width = 75
    Height = 25
    Caption = 'Button2'
    TabOrder = 2
    OnClick = Button2Click
  end
  object BitBtn1: TBitBtn
    Left = 200
    Top = 320
    Width = 75
    Height = 25
    Kind = bkClose
    NumGlyphs = 2
    TabOrder = 3
  end
  object Button3: TButton
    Left = 360
    Top = 312
    Width = 75
    Height = 25
    Caption = 'Button3'
    TabOrder = 4
    OnClick = Button3Click
  end
  object Edit3: TEdit
    Left = 168
    Top = 200
    Width = 297
    Height = 23
    TabOrder = 5
    Text = 'Edit3'
  end
  object Button1: TButton
    Left = 240
    Top = 256
    Width = 75
    Height = 25
    Caption = 'capturar N'
    TabOrder = 6
    OnClick = Button1Click
  end
  object MainMenu1: TMainMenu
    Left = 552
    Top = 32
    object ejercio11: TMenuItem
      Caption = 'ejercio1'
      object ejercio12: TMenuItem
        Caption = 'ejm1'
        OnClick = ejercio12Click
      end
    end
  end
end
