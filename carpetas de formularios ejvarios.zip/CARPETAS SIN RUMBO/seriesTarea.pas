unit seriesTarea;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.Buttons, Vcl.StdCtrls, Vcl.Menus;

type
  TForm1 = class(TForm)
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Edit1: TEdit;
    Edit2: TEdit;
    ListBox1: TListBox;
    Button1: TButton;
    BitBtn1: TBitBtn;
    MainMenu1: TMainMenu;
    series1: TMenuItem;
    series2: TMenuItem;
    parimpar1: TMenuItem;
    doblecuadrado1: TMenuItem;
    fibonaccidoble1: TMenuItem;
    cuadradomultiplode31: TMenuItem;
    dobledefibo1: TMenuItem;
    practico41: TMenuItem;
    see1: TMenuItem;
    serie21: TMenuItem;
    tareamiercoles1: TMenuItem;
    serieuno1: TMenuItem;
    seriedos1: TMenuItem;
    serietres1: TMenuItem;
    seriecuatro1: TMenuItem;
    procedure parimpar1Click(Sender: TObject);
    procedure doblecuadrado1Click(Sender: TObject);
    procedure fibonaccidoble1Click(Sender: TObject);
    procedure cuadradomultiplode31Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure dobledefibo1Click(Sender: TObject);
    procedure see1Click(Sender: TObject);
    procedure serieuno1Click(Sender: TObject);
    procedure seriedos1Click(Sender: TObject);
    procedure serietres1Click(Sender: TObject);
    procedure seriecuatro1Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form1: TForm1;

implementation

{$R *.dfm}

procedure TForm1.Button1Click(Sender: TObject);
begin
   edit1.clear;
   edit2.clear;
   listbox1.clear;
   edit1.setFocus;
end;

procedure TForm1.cuadradomultiplode31Click(Sender: TObject);
   var n,i,c,mul:integer;
begin
     n:=StrToInt(edit1.text); c:=0; i:=1; mul:=0;
       while c <= n do
       begin
         mul:= i*i;
           if mul mod 3 = 0 then
           begin
             listbox1.Items.Add(IntToStr(mul));
           end;
           i:=i+1;
           c:=c+1;
       end;

end;

procedure TForm1.doblecuadrado1Click(Sender: TObject);
 var n,d,q,iq,c : integer;
     sw:boolean;
begin
     d:=1; q:=1; iq:=3; sw:= true; n:= StrToInt(edit1.text);
       for c := 1 to n do
        begin
          if sw = true then
             begin
               listbox1.Items.Add(IntToStr(d));
                d:= d*2;
                sw:= false;

             end
             else
             begin
               listbox1.Items.Add(IntToStr(q));
               q:=q+iq;
               iq:=IQ+2;
               sw:= true;
             end;
        end;

end;

procedure TForm1.dobledefibo1Click(Sender: TObject);
  var n,c,fibo,f1,f2:integer;

begin
     n:= StrToInt(edit1.text); c:=0; fibo:=0; f1:=1; f2:=0;
       while c<= n do
       begin
         fibo:= f1+2*f2;
           listbox1.Items.Add(IntToStr(fibo));
           f1:=f2;
           f1:=fibo;
           c:=c+1;
       end;

end;

procedure TForm1.fibonaccidoble1Click(Sender: TObject);
 var n,c,fibo,f1,f2,fibona,fa,fb : integer;
     sw:boolean;
 begin
        n:=StrToInt(edit1.text); c:= 1; fibo:=0; f1:=1; f2:=0; fibona:=0; fa:=1; fb:=0;

       while c<=n do begin

          if sw = true then  begin

               fibo:=f1+f2;
               listbox1.Items.Add(IntToStr(fibo));
               f1:=f2;
               f2:=fibo;
               sw:= false;
           end else begin

               fibona:=fa+fb;
               listbox1.Items.Add(IntToStr(fibona));
               fa:=fb;
               fb:= fibona;
               sw:=true;
             end;
             c:= c +1;
       end;

 end;

procedure TForm1.parimpar1Click(Sender: TObject);
 var num : integer ;

begin
   num:=StrToInt(edit1.text);
    if num mod 2 = 0 then begin
       listbox1.Items.Add('el numero es par');
      end else begin
        listbox1.Items.Add('el numero es impar');
    end;
end;
procedure TForm1.see1Click(Sender: TObject);
var n,c,a,ia,b,ib : integer;
     sw : boolean;

begin
     n:=StrToInt(edit1.text); c:=1; a:=31; b:=41; ia:=28; ib:=12; sw:= true;
      for c := 1 to n do
      begin
           if sw=true then
           begin
             listbox1.Items.Add(IntToStr(a));
             a:=a+ia;
             ia:=ia+2;
             sw:=false;
           end else begin
             listbox1.Items.Add(IntToStr(b));
             b:=b+ib;
             ib:=(ib*2)+2;
             sw:= true;
           end;

      end;

end;

procedure TForm1.seriecuatro1Click(Sender: TObject);
var
  n, c, fibo, f1, f2, fac, sum: Integer;
  sw: Boolean;
begin
  n := StrToInt(edit1.text);
  fibo := 0;
  f1 := 1;
  f2 := 1;
  fac := 1;
  sum := 0;
  sw := True;
  for c := 1 to n do
  begin
    if sw then
    begin
      if c = 1 then
      begin
        fibo := f1;
      end
      else
      begin
        fibo := f1 + f2;
        f1 := f2;
        f2 := fibo;
      end;

      sum := sum + fibo;
      sw := False;
    end
    else
    begin
      fac := fac * c;
      sum := sum + fac;
      sw := True;
    end;
  end;


  listbox1.Items.Add('La suma de la serie es: ' + IntToStr(sum));
end;

procedure TForm1.seriedos1Click(Sender: TObject);
var
  n, a, b, c, fac, sum, ia: real;
begin
  n := StrToFloat(edit1.text);
  a := 1;
  ia := 1;
  fac := 1;
  c := 1;
  sum := 0;

  while c <= n do
  begin
    fac := fac * c;
    sum := sum + ((a * ia) / fac);
    ia := ia + 1;
    c := c + 1;
  end;

  listbox1.Items.Add('La sumatoria de la serie es:');
  listbox1.Items.Add(FloatToStr(sum));
end;

procedure TForm1.serietres1Click(Sender: TObject);
var
  n, i, c, sum, a: Integer;
begin

  n := StrToInt(edit1.text);
  sum := 0;
  for i := 1 to n do
  begin
    a := 1;
    for c := 1 to i do
    begin
      a := a * i;
    end;
    sum := sum + a;
  end;
  listbox1.Items.Add('la sumatoria es :'+  IntToStr(sum));

end;


procedure TForm1.serieuno1Click(Sender: TObject);

var
  n, sum, c: Integer;

begin

  showmessage('Ingrese el valor de n (m�ximo 12): ');
  n:=StrToInt(edit1.text);
  if n > 12 then
  begin
    n := 12;
  end;
  sum := 0;
  c := 1;
  while c <= n do
  begin
    if c = 1 then
      sum := sum + 1;
    if c = 2 then
      sum := sum + 2;
    if c = 3 then
      sum := sum + 3;
    if c = 4 then
      sum := sum + 3;
    if c = 5 then
      sum := sum + 2;
    if c = 6 then
      sum := sum + 1;
    if c = 7 then
      sum := sum + 1;
    if c = 8 then
      sum := sum + 2;
    if c = 9 then
      sum := sum + 2;
    if c = 10 then
      sum := sum + 1;
    if c = 11 then
      sum := sum + 1;
    if c = 12 then
      sum := sum + 1;
    c := c + 1;
  end;
  listbox1.Items.Add('el resultado de la sumatoria es:');
 listbox1.Items.Add(IntToStr( sum));
end;
end.
