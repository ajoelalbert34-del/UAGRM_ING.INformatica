unit UFpracticas;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls;

type
  TForm1 = class(TForm)
    crear: TLabel;
    Edit1: TEdit;
    Edit2: TEdit;
    CsmbiarValor: TLabel;
    BORRAR: TButton;
    procedure BORRARClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form1: TForm1;

implementation

{$R *.dfm}

procedure TForm1.BORRARClick(Sender: TObject);
begin
 edit1.Clear;
  edit2.Clear;
end;

end.
