object Form1: TForm1
  Left = 0
  Top = 0
  Caption = 'Form1'
  ClientHeight = 441
  ClientWidth = 624
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = 'Segoe UI'
  Font.Style = []
  Menu = MainMenu1
  PixelsPerInch = 96
  TextHeight = 15
  object Label1: TLabel
    Left = 24
    Top = 48
    Width = 34
    Height = 15
    Caption = 'Label1'
  end
  object Label2: TLabel
    Left = 24
    Top = 104
    Width = 34
    Height = 15
    Caption = 'Label2'
  end
  object Label3: TLabel
    Left = 24
    Top = 168
    Width = 34
    Height = 15
    Caption = 'Label3'
  end
  object Edit1: TEdit
    Left = 96
    Top = 48
    Width = 265
    Height = 23
    TabOrder = 0
    Text = 'Edit1'
  end
  object Edit2: TEdit
    Left = 96
    Top = 101
    Width = 265
    Height = 23
    TabOrder = 1
    Text = 'Edit2'
  end
  object Edit3: TEdit
    Left = 96
    Top = 165
    Width = 265
    Height = 23
    TabOrder = 2
    Text = 'Edit3'
  end
  object Button1: TButton
    Left = 15
    Top = 216
    Width = 75
    Height = 49
    Caption = 'capturarCAD'
    TabOrder = 3
    OnClick = Button1Click
  end
  object Button2: TButton
    Left = 177
    Top = 216
    Width = 75
    Height = 49
    Caption = 'Longuitud'
    TabOrder = 4
    OnClick = Button2Click
  end
  object Button3: TButton
    Left = 96
    Top = 271
    Width = 75
    Height = 42
    Caption = 'borrar'
    TabOrder = 5
    OnClick = Button3Click
  end
  object ListBox1: TListBox
    Left = 424
    Top = 104
    Width = 192
    Height = 305
    ItemHeight = 15
    TabOrder = 6
  end
  object BitBtn1: TBitBtn
    Left = 280
    Top = 232
    Width = 75
    Height = 65
    Kind = bkClose
    NumGlyphs = 2
    TabOrder = 7
  end
  object Button4: TButton
    Left = 8
    Top = 319
    Width = 137
    Height = 41
    Caption = 'capturarCARACTER'
    TabOrder = 8
    OnClick = Button4Click
  end
  object MainMenu1: TMainMenu
    Left = 552
    Top = 32
    object cadenas11: TMenuItem
      Caption = 'cadenas1'
      object cadenas12: TMenuItem
        Caption = 'invertirlogica'
        OnClick = cadenas12Click
      end
      object invertirfisica1: TMenuItem
        Caption = 'invertirfisica'
        OnClick = invertirfisica1Click
      end
      object escapicua1: TMenuItem
        Caption = 'escapicua'
        OnClick = escapicua1Click
      end
      object escapicua2: TMenuItem
        Caption = 'indice impar'
        OnClick = escapicua2Click
      end
      object caracIguales1: TMenuItem
        Caption = 'caracIguales'
        OnClick = caracIguales1Click
      end
    end
    object pruebas1: TMenuItem
      Caption = 'pruebas'
      object pruebas2: TMenuItem
        Caption = 'prueba1'
        OnClick = pruebas2Click
      end
    end
    object examepractico1: TMenuItem
      Caption = 'examepractico'
      object examepractico2: TMenuItem
        Caption = 'ejercicio1'
        OnClick = examepractico2Click
      end
      object ejercicio21: TMenuItem
        Caption = 'ejercicio2'
        OnClick = ejercicio21Click
      end
    end
  end
end
