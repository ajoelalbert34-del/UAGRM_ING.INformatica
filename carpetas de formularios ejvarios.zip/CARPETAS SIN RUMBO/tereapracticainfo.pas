unit tereapracticainfo;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.Buttons, Vcl.StdCtrls, Vcl.Menus;

type
  TForm1 = class(TForm)
    MainMenu1: TMainMenu;
    Button1: TButton;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Edit1: TEdit;
    Edit2: TEdit;
    Button2: TButton;
    BitBtn1: TBitBtn;
    modulo11: TMenuItem;
    modulo12: TMenuItem;
    SumarDigitos1: TMenuItem;
    Promedio1: TMenuItem;
    Promedio2: TMenuItem;
    DigitoMayor1: TMenuItem;
    DigitoMayor2: TMenuItem;
    EsCapicua1: TMenuItem;
    funcionesnaturales1: TMenuItem;
    funcion11: TMenuItem;
    Button3: TButton;
    cadenas1: TMenuItem;
    cadenas2: TMenuItem;
    buscarcaracterYvcesquerepitio1: TMenuItem;
    Button4: TButton;
    Button5: TButton;
    EspaciosEnBlanco1: TMenuItem;
    Mayusculas1: TMenuItem;
    Minusculas1: TMenuItem;
    BuscarCaracte1: TMenuItem;
    Vocales1: TMenuItem;
    CarecterTeclado1: TMenuItem;
    CarecterTeclado2: TMenuItem;
    Edit3: TEdit;
    funcionesYprocedimientos1: TMenuItem;
    serie11: TMenuItem;
    serie12: TMenuItem;
    serie31: TMenuItem;
    examenpractico1: TMenuItem;
    ejercio11: TMenuItem;
    ListBox1: TListBox;
    funcion21: TMenuItem;
    procedure Button1Click(Sender: TObject);
    procedure modulo12Click(Sender: TObject);
    procedure SumarDigitos1Click(Sender: TObject);
    procedure Promedio1Click(Sender: TObject);
    procedure Promedio2Click(Sender: TObject);
    procedure DigitoMayor1Click(Sender: TObject);
    procedure DigitoMayor2Click(Sender: TObject);
    procedure EsCapicua1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure funcion11Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure cadenas2Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure Button5Click(Sender: TObject);
    procedure EspaciosEnBlanco1Click(Sender: TObject);
    procedure Mayusculas1Click(Sender: TObject);
    procedure serie11Click(Sender: TObject);
    procedure serie12Click(Sender: TObject);
    procedure ejercio11Click(Sender: TObject);
    procedure funcion21Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form1: TForm1;
  n:word;
   c,can,i:byte;
   cap:boolean;
    cad:string;
    car:char;
implementation
 //implementaciondefunciones
{$R *.dfm}
  function contardigitos(n:word):integer;
var  contador,c:integer;
begin
  contador := 0;
  n := Abs(n);
  if n = 0 then
    contador := 1
  else
  begin
    while n > 0 do
    begin
      n := n div 10;
      contador := contador + 1;
    end;
  end;
  Result := contador;
end;

  function SumarDigitos(n: word): Integer;
var
  suma, digito: Integer;
begin
  suma := 0;
  n := Abs(n);
  while n > 0 do
  begin
    digito := n mod 10;
    suma := suma + digito;
    n := n div 10;
  end;
  Result := suma;
end;
    function promediodigitos(n:word): Real;
var
  suma, digito, contador: Integer;
begin
  suma := 0;
  contador := 0;
  n := Abs(n);
  if n = 0 then
  begin
    Result := 0;
  end;
  while n > 0 do
  begin
    digito := n mod 10;
    suma := suma + digito;
    contador := contador + 1;
    n := n div 10;
  end;
  Result := suma / contador;
end;

   function invertirnumero(n:word): Integer;
var
  invertido, digito: Integer;
begin
  invertido := 0;
  n := Abs(n);
  while n > 0 do
  begin
    digito := n mod 10;
    invertido := invertido * 10 + digito;
    n := n div 10;
  end;
  Result := invertido;
end;

  function digitomayor(n: word): Integer;
var
  digito, mayor: Integer;
begin
  mayor := 0;
  n := Abs(n);
  while n > 0 do
  begin
    digito := n mod 10;
    if digito > mayor then
      mayor := digito;
    n := n div 10;
  end;
  Result := mayor;
end;

     function PromedioPar(n: Integer): Real;
var
  digito, suma, contador: Integer;
begin
  suma := 0;
  contador := 0;
  n := Abs(n);
  while n > 0 do
  begin
    digito := n mod 10;
    if digito mod 2 = 0 then
    begin
      suma := suma + digito;
      contador := contador + 1;
    end;
    n := n div 10;
  end;
  if contador > 0 then
    Result := suma / contador
  else
    Result := 0;
end;

function escapicua(n: word):string;
var
  original, invertido, digito: Integer;
  a,b:string;
begin
  original := Abs(n);
  invertido := 0;
  while n > 0 do
  begin
    digito := n mod 10;
    invertido := invertido * 10 + digito;
    n := n div 10;
  end;
    if invertido = original then
    begin
      result:=('es capicua') ;
    end else begin
      result:= ('no es capicua') ;
    end;

end;
       //////longuitud de cadena
    function longuitud(cad:string):integer;
     var cantidad : integer ;
    begin
     cantidad:= length(cad) ;
      result:= cantidad;
    end;

    ///implementar funciones de cadena
    function eblanco(cad:string; can,i:byte) : byte;
     var eb: byte;
      begin
         eb :=0 ; //inicializar el espacio en blanco
         i:=1 ;
         while i<= can  do   begin
           if cad[i]='' then
           eb:=eb+1;
           i:=i+1;


         end;
           result:=eb;
      end;

       function mayus(cad:string; can,i:byte):byte;
       const may : set of char = ['A'..'Z'];
       var  cm: byte;

      begin
        i:=1; cm:=0;
        while i<=can do
        begin
          if cad[i] in may then
          cm:=cm+1;
          i:=i+1;
        end;

        result:=cm;
      end;
    ////


 ///FUNCIONES NATURALES
 function SumarDigitosImparesMayoresA3(Numero: Integer): Integer;
var
  Digito, Suma: Integer;
begin
  Suma := 0;
  while Numero > 0 do
  begin
    Digito := Numero mod 10;
    Numero := Numero div 10;
    if (Digito mod 2 = 1) and (Digito > 3) then
      Suma := Suma + Digito;
  end;
  Result := Suma;
end;

function DigitoMayorEnIndicesImpares(n: Integer): Integer;
var
  i, Digito, Mayor: Integer;
  nStr: string;
begin
  nStr := IntToStr(n);
  Mayor := -1;
  for i := 1 to Length(nStr) do
  begin
    if i mod 2 = 1 then
    begin
      Digito := StrToInt(nStr[i]);
      if Digito > Mayor then
        Mayor := Digito;
    end;
  end;
  Result := Mayor;
end;

function SumarMayorYMenorDigito(n: Integer): Integer;
var
  Digito, Mayor, Menor: Integer;
  nStr: string;
  i: Integer;
begin
  nStr := IntToStr(n);
  Mayor := StrToInt(nStr[1]);
  Menor := StrToInt(nStr[1]);
  for i := 2 to Length(nStr) do
  begin
    Digito := StrToInt(nStr[i]);
    if Digito > Mayor then
      Mayor := Digito;
    if Digito < Menor then
      Menor := Digito;
  end;
  Result := Mayor + Menor;
end;

function PromedioDigitosMenoresA7(n: Integer): Real;
var
  Digito, Suma, Contador, i: Integer;
  nStr: string;
begin
  Suma := 0;
  Contador := 0;
  nStr := IntToStr(n);
  for i := 1 to Length(nStr) do
  begin
    Digito := StrToInt(nStr[i]);
    if Digito < 7 then
    begin
      Suma := Suma + Digito;
      Inc(Contador);
    end;
  end;
  if Contador = 0 then
    Result := 0
  else
    Result := Suma / Contador;
end;

procedure MostrarMayorYMenorDigito(n: Integer; var Mayor, Menor: Integer);
var
  Digito, i: Integer;
  nStr: string;
begin
  nStr := IntToStr(n);
  Mayor := StrToInt(nStr[1]);
  Menor := StrToInt(nStr[1]);
  for i := 2 to Length(nStr) do
  begin
    Digito := StrToInt(nStr[i]);
    if Digito > Mayor then
      Mayor := Digito;
    if Digito < Menor then
      Menor := Digito;
  end;
end;

procedure DigitoMayorMenor(n: Integer; out DigitoMayor, DigitoMenor: Integer);
var
  Digito: Integer;
begin
  DigitoMayor := n mod 10;
  DigitoMenor := n mod 10;
  while n > 0 do
  begin
    Digito := n mod 10;
    if Digito > DigitoMayor then
      DigitoMayor := Digito;
    if Digito < DigitoMenor then
      DigitoMenor := Digito;
    n := n div 10;
  end;
end;

function FormarNumeroConDigitosPares(n: Integer): Integer;
var
  Digito, NumeroPares, Factor: Integer;
begin
  NumeroPares := 0;
  Factor := 1;
  while n > 0 do
  begin
    Digito := n mod 10;
    if Digito mod 2 = 0 then
    begin
      NumeroPares := NumeroPares + Digito * Factor;
      Factor := Factor * 10;
    end;
    n := n div 10;
  end;
  Result := NumeroPares;
end;

procedure FormarParesEImpares(n: Integer; var Pares, Impares: Integer);
var
  Digito: Integer;
begin
  Pares := 0;
  Impares := 0;
  while n > 0 do
  begin
    Digito := n mod 10;
    n := n div 10;
    if Digito mod 2 = 0 then
      Pares := Pares * 10 + Digito
    else
      Impares := Impares * 10 + Digito;
  end;
end;

function MayorDigitoPar(n: Integer): Integer;
var
  Digito, Mayor: Integer;
begin
  Mayor := -1;
  while n > 0 do
  begin
    Digito := n mod 10;
    n := n div 10;
    if (Digito mod 2 = 0) and (Digito > Mayor) then
      Mayor := Digito;
  end;
  Result := Mayor;
end;

procedure MostrarDigitosMultiplosDeTres(n: Integer);
var
  Digito: Integer;
begin
  while n > 0 do
  begin
    Digito := n mod 10;
    n := n div 10;
    if Digito mod 3 = 0 then
      Writeln(Digito);
  end;
end;

procedure ObtenerPrimerYUltimoDigito(n: Integer; var PrimerDigito, UltimoDigito: Integer);
begin
  UltimoDigito := n mod 10;
  while n >= 10 do
    n := n div 10;
  PrimerDigito := n;
end;

function EliminarPrimeroYUltimoDigito(n: Integer): Integer;
var
  Factor: Integer;
begin
  if n < 100 then
    Result := 0
  else
  begin
    n := n div 10;
    Factor := 1;
    while n div Factor >= 10 do
      Factor := Factor * 10;
    Result := n mod Factor;
  end;
end;

function InverNumero(n: Integer): Integer;
var
  Invertido, Digito: Integer;
begin
  Invertido := 0;
  while n > 0 do
  begin
    Digito := n mod 10;
    Invertido := Invertido * 10 + Digito;
    n := n div 10;
  end;
  Result := Invertido;
end;

function ContarDigitosMultiplosDeCuatro(n: Integer): Integer;
var
  Digito, Conteo: Integer;
begin
  Conteo := 0;
  while n > 0 do
  begin
    Digito := n mod 10;
    if Digito mod 4 = 0 then
      Inc(Conteo);
    n := n div 10;
  end;
  Result := Conteo;
end;

function DigitoMenorMultiploDeTres(n: Integer): Integer;
var
  Digito, Menor: Integer;
begin
  Menor := 10;
  while n <> 0 do
  begin
    Digito := n mod 10;
    n := n div 10;
    if (Digito mod 3 = 0) and (Digito < Menor) then
      Menor := Digito;
  end;
  if Menor = 10 then
    Result := 0
  else
    Result := Menor;
end;

function VerCapicua(n: Integer): Boolean;
var
  Invertido, Original, Digito: Integer;
begin
  Original := n;
  Invertido := 0;
  while n <> 0 do
  begin
    Digito := n mod 10;
    Invertido := Invertido * 10 + Digito;
    n := n div 10;
  end;
  Result := (Original = Invertido);
end;

function ConvertirABinario(n: Integer): String;
var
  Binario: String;
begin
  Binario := '';
  while n > 0 do
  begin
    Binario := IntToStr(n mod 2) + Binario;
    n := n div 2;
  end;
  if Binario = '' then
    Binario := '0';
  Result := Binario;
end;

function ConvertirAHexadecimal(n: Integer): String;
var
  Hexadecimal: String;
  Resto: Integer;
begin
  Hexadecimal := '';
  while n > 0 do
  begin
    Resto := n mod 16;
    if Resto < 10 then
      Hexadecimal := Chr(Ord('0') + Resto) + Hexadecimal
    else
      Hexadecimal := Chr(Ord('A') + (Resto - 10)) + Hexadecimal;
    n := n div 16;
  end;
  if Hexadecimal = '' then
    Hexadecimal := '0';
  Result := Hexadecimal;
end;

function ConvertirAOctal(n: Integer): String;
var
  Octal: String;
begin
  Octal := '';
  while n > 0 do
  begin
    Octal := IntToStr(n mod 8) + Octal;
    n := n div 8;
  end;
  if Octal = '' then
    Octal := '0';
  Result := Octal;
end;

function SumarDigitosPrimos(n: Integer): Integer;
var
  Suma, Digito: Integer;
begin
  Suma := 0;
  while n <> 0 do
  begin
    Digito := n mod 10;
    n := n div 10;
    if Digito in [2, 3, 5, 7] then
      Suma := Suma + Digito;
  end;
  Result := Suma;
end;

function PromedioMultiplosDeTresYCinco(n: Integer): Double;
var
  Suma, Contador, Digito: Integer;
begin
  Suma := 0;
  Contador := 0;
  while n <> 0 do
  begin
    Digito := n mod 10;
    n := n div 10;
    if Digito in [0, 5] then
    begin
      Suma := Suma + Digito;
      Inc(Contador);
    end;
  end;
  if Contador = 0 then
    Result := 0
  else
    Result := Suma / Contador;
end;

function EsPrimo(Digito: Integer): Boolean;
begin
  Result := (Digito = 2) or (Digito = 3) or (Digito = 5) or (Digito = 7);
end;

function PromedioDigitosPrimos(n: Integer): Real;
var
  Digito, Suma, Conteo: Integer;
begin
  Suma := 0;
  Conteo := 0;
  while n > 0 do
  begin
    Digito := n mod 10;
    if EsPrimo(Digito) then
    begin
      Suma := Suma + Digito;
      Inc(Conteo);
    end;
    n := n div 10;
  end;
  if Conteo = 0 then
    Result := 0
  else
    Result := Suma / Conteo;
end;

function FormarNumeroConDigitosPrimos(n: Integer): Integer;
var
  Digito, NuevoNumero, Factor: Integer;
begin
  NuevoNumero := 0;
  Factor := 1;
  while n > 0 do
  begin
    Digito := n mod 10;
    if EsPrimo(Digito) then
    begin
      NuevoNumero := Digito * Factor + NuevoNumero;
      Factor := Factor * 10;
    end;
    n := n div 10;
  end;
  if NuevoNumero = 0 then
    Result := 0
  else
    Result := NuevoNumero;
end;

 //////  fin de funciones y procemientos naturales
 ////examen practico
 function serie1(n:integer):real ;
 var fac,expo,base,c:integer;
      serie,sumador:real;
 begin
     fac:=1;   base:=1; expo:=2; c:=1; serie:=0;  sumador:=0;
     while c<=n do
     begin
      fac:=fac*c;
      base:= base * base ;
        serie:= fac / base ;
         sumador:= sumador + serie ;
       c:=c+1;
       base:=base+1;

     end;
        result:= sumador;
 end;

 function  serie2(n:integer):integer;
  var one,c,i,sum,f1,f2,fibo: integer;
     sw:boolean;

   begin
       one:=3; i:=4; sum:=0; f1:=1; f2:=4; fibo:=0; sw:=true; c:=1;

        while c<=n do
        begin
           if sw=true then
           begin

             sum:= sum+one;
             one:= one + i;
             sw:=false;
           end else begin
                fibo := f1+f2;
            sum:= fibo+ sum;
            f1:=f2;
            f2:=fibo;
            sw:=true;
           end;

           c:=c+1;
        end;
         result:= sum ;
   end;


 ////fin examen practico
 ///// exame practico #3
 procedure cadarbol( cad:string);

  var n, c,resta :integer;
 begin
    n:= length(cad);  c:=1; resta:=0;
      for i := 1 to n do

        begin

         // listbox1.txt.ADD(Str(cad));
          resta:= StrToInt( cad) - StrToInt(cad[c]) ;
           cad:= IntToStr(resta);
        end;
 end;




 //////fin de examen practico
 ////tarea viernes
 function EliminarVocales(const cad: string): string;
var
  i: Integer;
  resultado: string;
begin
  resultado := '';
  for i := 1 to Length(cad) do
  begin

    if not CharInSet(cad[i], ['a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U']) then
      resultado := resultado + cad[i];
  end;

  Result := resultado;
end;

 function ContarPalabrasQueTerminanEnVocal(const cad: string): Integer;
var
  i, contador: Integer;
  esPalabra: Boolean;
begin
  contador := 0;
  esPalabra := False;


  for i := 1 to Length(cad) do
  begin

    if cad[i] <> ' ' then
      esPalabra := True
    else
    begin

      if esPalabra and (i > 1) and CharInSet(cad[i - 1], ['a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U']) then
        contador:=contador + 1;
      esPalabra := False;
    end;
  end;


  if esPalabra and CharInSet(cad[Length(cad)], ['a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U']) then
    Inc(contador);

  Result := contador;
end;

    procedure ContarVocales( cad: string; aCont, eCont, iCont, oCont, uCont: Integer);
var
  i: Integer;
begin
  // Inicializar los contadores
  aCont := 0;
  eCont := 0;
  iCont := 0;
  oCont := 0;
  uCont := 0;

  // Recorrer cada car�cter de la cadena
  for i := 1 to Length(cad) do
  begin
    case cad[i] of
      'a', 'A': Inc(aCont); // Contar 'a' o 'A'
      'e', 'E': Inc(eCont); // Contar 'e' o 'E'
      'i', 'I': Inc(iCont); // Contar 'i' o 'I'
      'o', 'O': Inc(oCont); // Contar 'o' o 'O'
      'u', 'U': Inc(uCont); // Contar 'u' o 'U'
    end;
  end;
end;

 type
  TVocalConteo = array['a'..'u'] of Integer;

function ContarVocal(const cad: string): TVocalConteo;
var
  i: Integer;
  letra: Char;
  vocales: TVocalConteo;
begin

  for letra in ['a', 'e', 'i', 'o', 'u'] do
    vocales[letra] := 0;


  for i := 1 to Length(cad) do
  begin
    letra := LowerCase(cad[i])[1];
    if letra in ['a', 'e', 'i', 'o', 'u'] then
      Inc(vocales[letra]);
  end;

  Result := vocales;
end;

procedure MostrarConteoVocales(const conteo: TVocalConteo; listbox: TListBox);
begin
  // Limpiar la lista antes de mostrar los resultados
  listbox.Clear;

  // Mostrar el conteo de cada vocal en el ListBox
  listbox.Items.Add('a = ' + IntToStr(conteo['a']));
  listbox.Items.Add('e = ' + IntToStr(conteo['e']));
  listbox.Items.Add('i = ' + IntToStr(conteo['i']));
  listbox.Items.Add('o = ' + IntToStr(conteo['o']));
  listbox.Items.Add('u = ' + IntToStr(conteo['u']));
end;

 ////finitarea viernes

procedure TForm1.Button1Click(Sender: TObject);
begin
 n := StrToInt(Edit1.Text);
  ShowMessage('N�mero natural registrado: ' + IntToStr(n));
end;

procedure TForm1.Button2Click(Sender: TObject);
begin
 edit2.clear;
 edit1.clear ;
  edit3.Clear;
end;

procedure TForm1.Button3Click(Sender: TObject);
begin
   cad := edit1.text;
   ShowMessage('cadena regitrada: ' + edit1.text);
end;

procedure TForm1.Button4Click(Sender: TObject);
begin
 //edit1.text:= cad; //no registra datos
 cad:= edit1.Text;
  Showmessage('cadena registrada en el arreglo');
  edit1.Clear;
end;

procedure TForm1.Button5Click(Sender: TObject);
begin
 can:=length(cad);
  edit3.Text:=  'la longuitud es : ' + IntToStr(can);
end;

procedure TForm1.cadenas2Click(Sender: TObject);
var
  cad: string;
begin
  cad := Edit1.Text;  // Obtienes el texto de Edit1 para calcular su longitud
  Edit2.Text := 'La cantidad de caracteres es: ' + IntToStr(longuitud(cad));

end;

procedure TForm1.DigitoMayor1Click(Sender: TObject);
begin
 edit2.text:= 'el digito mayor es :' + IntToStr(digitomayor(n));
end;

procedure TForm1.DigitoMayor2Click(Sender: TObject);
begin
 edit2.text:= 'el promedio es:' + FloatToStr(promediopar(n));
end;

procedure TForm1.ejercio11Click(Sender: TObject);

 var
  conteo: TVocalConteo;
  cadena: string;
begin
  cadena := Edit1.Text;
  MostrarConteoVocales(conteo, ListBox1);
end;

procedure TForm1.EsCapicua1Click(Sender: TObject);
begin
edit2.text:=  (escapicua(n));
end;

procedure TForm1.EspaciosEnBlanco1Click(Sender: TObject);
begin
       edit2.Text:= IntToStr(eblanco(cad,can,i)) + 'espacio en blanco';
end;

procedure TForm1.funcion11Click(Sender: TObject);
begin
edit2.Text:= IntToStr(MayorDigitoPar(n));
end;

procedure TForm1.funcion21Click(Sender: TObject);
var c,fac:integer;
begin
     while c>=n do
     begin
       fac:=fac * c;
       c:=c+1;
     end;
     edit2.Text:= IntToStr(fac);
end;

procedure TForm1.Mayusculas1Click(Sender: TObject);
begin
 edit2.Text:= IntToStr(mayus(cad,can,i)) + 'son mayuscula';
end;

procedure TForm1.modulo12Click(Sender: TObject);
begin
Edit2.Text := IntToStr(contardigitos(n)) + ' d�gitos';
end;

procedure TForm1.Promedio1Click(Sender: TObject);
begin
 edit2.text:= 'el promedio es : ' + FloatToStr(promediodigitos(n));
end;

procedure TForm1.Promedio2Click(Sender: TObject);
begin
 edit2.text:='invertido es:' + IntToStr(invertirnumero(n));
end;

procedure TForm1.serie11Click(Sender: TObject);
begin
 edit2.text := FloatToStr (serie1(n));
end;

procedure TForm1.serie12Click(Sender: TObject);
begin
 edit2.Text:= IntToStr(serie2(n));
end;

procedure TForm1.SumarDigitos1Click(Sender: TObject);
begin
 edit2.text:= 'la suma es :' + IntToStr(sumardigitos(n)) ;
end;

end.

