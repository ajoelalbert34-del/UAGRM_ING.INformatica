object Form1: TForm1
  Left = 349
  Top = 59
  Caption = 'Form1'
  ClientHeight = 487
  ClientWidth = 785
  Color = clMoneyGreen
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = 'Segoe UI'
  Font.Style = []
  Menu = MainMenu1
  Position = poDesigned
  PixelsPerInch = 96
  TextHeight = 15
  object Label1: TLabel
    Left = 40
    Top = 68
    Width = 148
    Height = 22
    Caption = 'ENTRADA'
    Font.Charset = ANSI_CHARSET
    Font.Color = clPurple
    Font.Height = -16
    Font.Name = 'Goudy Stout'
    Font.Style = [fsBold, fsItalic, fsUnderline]
    ParentFont = False
  end
  object Label2: TLabel
    Left = 40
    Top = 134
    Width = 116
    Height = 22
    Caption = 'SALIDA'
    Font.Charset = ANSI_CHARSET
    Font.Color = clPurple
    Font.Height = -16
    Font.Name = 'Goudy Stout'
    Font.Style = [fsBold, fsItalic, fsUnderline]
    ParentFont = False
  end
  object Label3: TLabel
    Left = 64
    Top = 203
    Width = 76
    Height = 21
    Caption = 'longuitud'
    Color = clAqua
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Segoe UI'
    Font.Style = [fsBold]
    ParentColor = False
    ParentFont = False
  end
  object Button1: TButton
    Left = 72
    Top = 296
    Width = 105
    Height = 65
    Caption = 'capturar N'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -12
    Font.Name = 'Segoe UI'
    Font.Style = []
    ParentFont = False
    TabOrder = 0
    OnClick = Button1Click
  end
  object Edit1: TEdit
    Left = 200
    Top = 69
    Width = 481
    Height = 23
    TabOrder = 1
    Text = 'Edit1'
  end
  object Edit2: TEdit
    Left = 200
    Top = 135
    Width = 481
    Height = 23
    TabOrder = 2
    Text = 'Edit2'
  end
  object Button2: TButton
    Left = 400
    Top = 324
    Width = 137
    Height = 25
    Caption = 'Button2'
    TabOrder = 3
    OnClick = Button2Click
  end
  object BitBtn1: TBitBtn
    Left = 230
    Top = 324
    Width = 75
    Height = 25
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clHotLight
    Font.Height = -12
    Font.Name = 'Segoe UI'
    Font.Style = []
    Kind = bkClose
    NumGlyphs = 2
    ParentFont = False
    TabOrder = 4
  end
  object Button3: TButton
    Left = 72
    Top = 392
    Width = 114
    Height = 41
    Caption = 'CAPTURAR CAD'
    TabOrder = 5
    OnClick = Button3Click
  end
  object Button4: TButton
    Left = 230
    Top = 384
    Width = 131
    Height = 64
    Caption = 'REGISTRAR CADENA'
    TabOrder = 6
    OnClick = Button4Click
  end
  object Button5: TButton
    Left = 384
    Top = 385
    Width = 129
    Height = 55
    Caption = 'LONGUITUD_CADENA'
    TabOrder = 7
    OnClick = Button5Click
  end
  object Edit3: TEdit
    Left = 200
    Top = 205
    Width = 473
    Height = 23
    TabOrder = 8
    Text = 'Edit3'
  end
  object ListBox1: TListBox
    Left = 568
    Top = 252
    Width = 121
    Height = 196
    ItemHeight = 15
    TabOrder = 9
  end
  object MainMenu1: TMainMenu
    Left = 672
    Top = 8
    object modulo11: TMenuItem
      Caption = 'modulo1'
      object modulo12: TMenuItem
        Caption = 'ContarDigitos'
        OnClick = modulo12Click
      end
      object SumarDigitos1: TMenuItem
        Caption = 'SumarDigitos'
        OnClick = SumarDigitos1Click
      end
      object Promedio1: TMenuItem
        Caption = 'Promedio'
        OnClick = Promedio1Click
      end
      object Promedio2: TMenuItem
        Caption = 'Invertir'
        OnClick = Promedio2Click
      end
      object DigitoMayor1: TMenuItem
        Caption = 'DigitoMayor'
        OnClick = DigitoMayor1Click
      end
      object DigitoMayor2: TMenuItem
        Caption = 'PromedioPar'
        OnClick = DigitoMayor2Click
      end
      object EsCapicua1: TMenuItem
        Caption = 'EsCapicua'
        OnClick = EsCapicua1Click
      end
    end
    object funcionesnaturales1: TMenuItem
      Caption = 'funcionesnaturales'
      object funcion11: TMenuItem
        Caption = 'funcion1'
        OnClick = funcion11Click
      end
      object funcion21: TMenuItem
        Caption = 'funcion2'
        OnClick = funcion21Click
      end
    end
    object cadenas1: TMenuItem
      Caption = 'cadenas '
      object cadenas2: TMenuItem
        Caption = 'longuitud de la cadena'
        OnClick = cadenas2Click
      end
      object buscarcaracterYvcesquerepitio1: TMenuItem
        Caption = 'buscarcaracterYvcesquerepitio'
      end
      object EspaciosEnBlanco1: TMenuItem
        Caption = 'EspaciosEnBlanco'
        OnClick = EspaciosEnBlanco1Click
      end
      object Mayusculas1: TMenuItem
        Caption = 'Mayusculas'
        OnClick = Mayusculas1Click
      end
      object Minusculas1: TMenuItem
        Caption = 'Minusculas'
      end
      object BuscarCaracte1: TMenuItem
        Caption = 'BuscarCaracte'
      end
      object Vocales1: TMenuItem
        Caption = 'Vocales'
      end
      object CarecterTeclado1: TMenuItem
        Caption = 'CarecterTeclado'
      end
      object CarecterTeclado2: TMenuItem
        Caption = 'CarecterTeclado'
      end
    end
    object funcionesYprocedimientos1: TMenuItem
      Caption = 'funcionesYprocedimientos'
      object serie11: TMenuItem
        Caption = 'serie1'
        OnClick = serie11Click
      end
      object serie12: TMenuItem
        Caption = 'seie2'
        OnClick = serie12Click
      end
      object serie31: TMenuItem
        Caption = 'serie3'
      end
    end
    object examenpractico1: TMenuItem
      Caption = 'examenpractico'
      object ejercio11: TMenuItem
        Caption = 'ejercio 1'
        OnClick = ejercio11Click
      end
    end
  end
end
