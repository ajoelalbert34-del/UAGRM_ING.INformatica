program UFpracticas1;

uses
  Vcl.Forms,
  UFpracticas in 'UFpracticas.pas' {Form1},
  UCpracticas in 'UCpracticas.pas',
  UCnaturales in 'UCnaturales.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TForm1, Form1);
  Application.Run;
end.
